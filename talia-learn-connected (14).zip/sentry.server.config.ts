// إعداد Sentry لجانب السيرفر (أي كود بيشتغل على سيرفر Vercel، مش في متصفح المستخدم).
import * as Sentry from '@sentry/nextjs';

Sentry.init({
  dsn: process.env.NEXT_PUBLIC_SENTRY_DSN,
  tracesSampleRate: 0.1,
  environment: process.env.NEXT_PUBLIC_VERCEL_ENV || 'development',
});
