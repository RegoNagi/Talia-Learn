// إعداد Sentry لرصد الأخطاء الحقيقية اللي بتحصل عند المستخدمين في المتصفح.
// الـ DSN بييجي من متغيّر بيئة (NEXT_PUBLIC_SENTRY_DSN) — لو مش متظبط، Sentry
// بيقفل نفسه تلقائي من غير ما يكسر أي حاجة.
import * as Sentry from '@sentry/nextjs';

Sentry.init({
  dsn: process.env.NEXT_PUBLIC_SENTRY_DSN,
  // نسبة العينات من الطلبات العادية اللي بتتسجل لأغراض الأداء (مش أخطاء).
  // ١٠٪ كافية نبدأ بيها، تقلل الحمل من غير ما نخسر الرؤية.
  tracesSampleRate: 0.1,
  // بيسجّل session replay بس للجلسات اللي فيها خطأ فعلي — مفيدة جدًا لفهم
  // "المستخدم كان بيعمل إيه لما الخطأ حصل" بدون ما نسجّل كل حاجة طول الوقت.
  replaysOnErrorSampleRate: 1.0,
  replaysSessionSampleRate: 0,
  integrations: [
    Sentry.replayIntegration({
      maskAllText: true,
      blockAllMedia: true,
    }),
  ],
  environment: process.env.NEXT_PUBLIC_VERCEL_ENV || 'development',
});
