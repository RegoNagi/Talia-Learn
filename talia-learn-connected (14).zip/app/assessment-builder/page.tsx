'use client';

import { useState, useEffect, Suspense, Fragment, startTransition } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, BrainCircuit, CheckCircle2, ChevronDown, Plus, 
  FileText, ListChecks, Image as ImageIcon, Type, 
  Trash2, GripVertical, Sparkles,
  Settings, Clock, Eye,
  UploadCloud, Scale,
  CheckSquare, Layout, Save, ArrowLeft, Pencil, Book,
  AlertCircle,
  Search, Check, Copy, Minus, Home, Loader2,
  Calculator, GitMerge, ListOrdered, Layers, Move, MousePointerClick, Mic, AlignLeft, PenLine, ArrowRight
} from 'lucide-react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { createPortal } from 'react-dom';
import { FloatingPortal } from '@floating-ui/react';
import { AssessmentSidebar } from '@/components/AssessmentSidebar';
import { useAuth } from '@/contexts/AuthContext';
import { createAssignment, createQuiz, uploadAssignmentAttachment, getSubmissionFileUrl, getUnitsForAssignment, getAssignmentById, getQuizById, updateAssignment, updateQuiz, getTeacherOtherClasses, getClassRoster } from '@/services/assignmentData';
import { getVisibleQuestions, convertBankQuestionToQuizQuestion, uploadQuestionImage, BankQuestion } from '@/services/questionBankData';
import { HotspotEditor } from '@/components/question-editor/HotspotEditor';
import { SubQuestionEditor } from '@/components/question-editor/SubQuestionEditor';
import { getGradebookCategories } from '@/services/academicData';

interface Question {
  id: string;
  type: 'multiple_choice' | 'true_false' | 'short_answer' | 'file_upload' | 'numeric_answer' | 'matching' | 'ordering' | 'classification' | 'drag_and_drop' | 'hotspot' | 'passage';
  text: string;
  points: number;
  imageUrl?: string;
  options?: { id: string; text: string; isCorrect: boolean; imageUrl?: string }[];
  sectionId?: string | null;
  numericAnswer?: number | null;
  numericTolerance?: number;
  numericUnit?: string;
  pairs?: { id: string; left: string; right: string }[];
  orderItems?: string[];
  categories?: string[];
  classifyItems?: { text: string; category: string }[];
  zones?: string[];
  dragItems?: { text: string; zone: string }[];
  hotspots?: { xPercent: number; yPercent: number; label: string; isCorrect: boolean }[];
  audioUrl?: string;
  passageText?: string;
  correctAnswer?: string;
  modelAnswer?: string;
  subQuestions?: { id: string; title: string; type: string; points: number; options?: { id: string; text: string; isCorrect: boolean }[] }[];
}

interface QuizSection {
  id: string;
  title: string;
  description?: string;
}

interface RubricLevel {
  id: string;
  score: number;
  title: string;
  description: string;
  color: 'red' | 'amber' | 'emerald' | 'blue';
}

interface RubricCriterion {
  id: string;
  title: string;
  weight: number;
  levels: RubricLevel[];
}

export const dynamic = 'force-dynamic';

function AssessmentBuilderContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { authUser } = useAuth();
  const scopeClassId = searchParams.get('classId') || '';
  const scopeSubject = searchParams.get('subject') || '';
  const scopeGrade = searchParams.get('grade') || '';
  const scopeUnitId = searchParams.get('unitId') || '';
  const editId = searchParams.get('id') || '';
  const [isEditLoading, setIsEditLoading] = useState(!!editId);
  const [selectedUnitId, setSelectedUnitId] = useState(scopeUnitId);
  const [availableUnits, setAvailableUnits] = useState<{ id: string; title: string }[]>([]);
  const [assignedClasses, setAssignedClasses] = useState<string[]>([]);
  const [assignedStudents, setAssignedStudents] = useState<string[]>([]);
  const [otherClasses, setOtherClasses] = useState<{ id: string; name: string }[]>([]);
  const [classRoster, setClassRoster] = useState<{ id: string; name: string }[]>([]);

  useEffect(() => {
    if (authUser?.teacherId && scopeClassId) {
      getTeacherOtherClasses(authUser.teacherId, scopeClassId).then(setOtherClasses);
    }
    if (scopeClassId) {
      getClassRoster(scopeClassId).then(setClassRoster);
    }
  }, [authUser?.teacherId, scopeClassId]);

  useEffect(() => {
    if (scopeClassId && scopeSubject) {
      getUnitsForAssignment(scopeClassId, scopeSubject).then(setAvailableUnits);
    }
  }, [scopeClassId, scopeSubject]);
  const returnTo = searchParams.get('from') || '';

  const goBack = () => {
    if (returnTo) router.push(decodeURIComponent(returnTo));
    else router.back();
  };
  const [isSavingReal, setIsSavingReal] = useState(false);
  const [saveError, setSaveError] = useState('');
  const initialType = (searchParams.get('type') === 'quiz' ? 'quiz' : 'assignment') as 'quiz' | 'assignment';
  const [activeTab] = useState<'quiz' | 'assignment'>(initialType);
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('');
  const [gradebookCategories, setGradebookCategories] = useState<string[]>([]);

  useEffect(() => {
    const grade = searchParams.get('grade') || '';
    if (scopeSubject && grade) {
      getGradebookCategories(scopeSubject, grade).then((cats) => {
        setGradebookCategories(cats);
        if (cats.length > 0 && !category) setCategory(cats[0]);
      });
    }
  }, [scopeSubject]);
  const [maxScore, setMaxScore] = useState(100);
  const [isAutoCalc, setIsAutoCalc] = useState(true);
  
  // Settings
  const [attemptLimit, setAttemptLimit] = useState('1');
  const [timeLimitHours, setTimeLimitHours] = useState('1');
  const [timeLimitMinutes, setTimeLimitMinutes] = useState('0');
  const [dueDate, setDueDate] = useState('');
  const [hasReleaseCondition, setHasReleaseCondition] = useState(false);
  const [releaseDate, setReleaseDate] = useState('');
  const [releaseTime, setReleaseTime] = useState('00:00');
  const [dueTime, setDueTime] = useState('23:59');
  
  // Security & Display
  const [shuffleQuestions, setShuffleQuestions] = useState(false);
  const [oneAtATime, setOneAtATime] = useState(false);
  const [prohibitLateSubmissions, setProhibitLateSubmissions] = useState(false);
  const [noDueDate, setNoDueDate] = useState(false);
  const [prohibitNewAttemptsAfterDueDate, setProhibitNewAttemptsAfterDueDate] = useState(false);
  const [randomizeAnswers, setRandomizeAnswers] = useState(false);
  const [randomizePages, setRandomizePages] = useState(false);
  const [prohibitBacktracking, setProhibitBacktracking] = useState(false);
  const [feedbackTiming, setFeedbackTiming] = useState('instantly');
  const [aiPlagiarism, setAiPlagiarism] = useState(true);
  const [publishToTimeline, setPublishToTimeline] = useState(true);

  // UI State
  const [isAIDraftRoomOpen, setIsAIDraftRoomOpen] = useState(false);
  const [isBankDrawerOpen, setIsBankDrawerOpen] = useState(false);
  const [bankQuestions, setBankQuestions] = useState<BankQuestion[]>([]);
  const [isLoadingBank, setIsLoadingBank] = useState(false);
  const [bankSearch, setBankSearch] = useState('');
  const [selectedBankIds, setSelectedBankIds] = useState<string[]>([]);

  useEffect(() => {
    if (isBankDrawerOpen && scopeSubject && scopeGrade) {
      startTransition(() => setIsLoadingBank(true));
      getVisibleQuestions({ teacherId: authUser?.teacherId, isSupervisor: authUser?.role === 'qb_supervisor', subject: scopeSubject, grade: scopeGrade }).then((qs) => {
        setBankQuestions(qs);
        setIsLoadingBank(false);
      });
      startTransition(() => setSelectedBankIds([]));
    }
  }, [isBankDrawerOpen, authUser?.teacherId, scopeSubject, scopeGrade]);

  const toggleBankSelection = (id: string) => {
    setSelectedBankIds((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]);
  };

  const handleAddSelectedBankQuestions = () => {
    const toAdd = bankQuestions
      .filter((bq) => selectedBankIds.includes(bq.id))
      .map((bq) => ({ ...convertBankQuestionToQuizQuestion(bq, 1), id: `q-${window.crypto.randomUUID()}`, sectionId: activeSectionId }));
    setQuestions((prev) => [...prev, ...toAdd]);
    setIsBankDrawerOpen(false);
    addToast(`${toAdd.length} Question(s) Added`);
  };

  const filteredBankQuestions = bankQuestions.filter((bq) =>
    (bq.title || '').toLowerCase().includes(bankSearch.toLowerCase())
  );
  const [toasts, setToasts] = useState<{ id: string; message: string }[]>([]);

  // AI Strategy Room State
  const [strategyTab, setStrategyTab] = useState<'strategy' | 'instant'>('strategy');
  const [isGeneratingStrategy, setIsGeneratingStrategy] = useState(false);
  const [hasGeneratedQuiz, setHasGeneratedQuiz] = useState(false);
  const [selectedLessons, setSelectedLessons] = useState<string[]>(['1.1']);
  const [selectedBloom, setSelectedBloom] = useState<string>('Application');
  const [difficulty, setDifficulty] = useState<string>('Intermediate');
  const [magicPrompt, setMagicPrompt] = useState('');
  const [questionCount, setQuestionCount] = useState<number>(5);
  const [generatedQuestions, setGeneratedQuestions] = useState<any[]>([]);
  const [status, setStatus] = useState<'published' | 'draft'>('draft');

  // Quiz State
  const [questions, setQuestions] = useState<Question[]>([
    {
      id: 'q1',
      type: 'multiple_choice',
      text: 'Which of the following best describes the primary function of a mitochondria?',
      points: 10,
      options: [
        { id: 'opt1', text: 'Protein synthesis', isCorrect: false },
        { id: 'opt2', text: 'Energy production (ATP)', isCorrect: true },
        { id: 'opt3', text: 'Cell division', isCorrect: false },
        { id: 'opt4', text: 'Photosynthesis', isCorrect: false },
      ]
    }
  ]);

  // Assignment State
  const [instructionsText, setInstructionsText] = useState('');
  const [attachments, setAttachments] = useState<{ name: string; storagePath: string }[]>([]);
  const [isUploadingAttachment, setIsUploadingAttachment] = useState(false);
  const [isUploadingQImage, setIsUploadingQImage] = useState<string | null>(null);
  const [isUploadingOptImage, setIsUploadingOptImage] = useState<string | null>(null);
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [previewQuestionIndex, setPreviewQuestionIndex] = useState(0);
  const [previewQuestionsShuffled, setPreviewQuestionsShuffled] = useState<Question[]>([]);
  useEffect(() => {
    if (!shuffleQuestions) { startTransition(() => setPreviewQuestionsShuffled(questions)); return; }
    const arr = [...questions];
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    startTransition(() => setPreviewQuestionsShuffled(arr));
  }, [isPreviewMode, shuffleQuestions, questions]);
  const [allowFileUpload, setAllowFileUpload] = useState(true);
  const [allowTextEntry, setAllowTextEntry] = useState(true);
  const [passPercentage, setPassPercentage] = useState(65);
  const [latePenalty, setLatePenalty] = useState('none');
  const [allowLateSubmission, setAllowLateSubmission] = useState(false);
  const [lockModule, setLockModule] = useState(false);
  const [gradingMethod, setGradingMethod] = useState<'Points' | 'Percentage' | 'Scale'>('Points');

  useEffect(() => {
    if (activeTab === 'assignment') startTransition(() => setGradingMethod('Points'));
  }, [activeTab]);

  const [isGeneratingRubric, setIsGeneratingRubric] = useState(false);
  const [rubric, setRubric] = useState<RubricCriterion[]>([
    {
      id: 'crit1',
      title: 'Critical Thinking',
      weight: 40,
      levels: [
        { id: 'l1', score: 0, title: 'POOR', description: 'Lacks basic understanding and analysis.', color: 'red' }, 
        { id: 'l2', score: 50, title: 'GOOD', description: 'Shows good comprehension but misses nuance.', color: 'amber' },
        { id: 'l3', score: 100, title: 'EXCELLENT', description: 'Exceptional analysis and insight.', color: 'emerald' }
      ]
    },
    {
      id: 'crit2',
      title: 'Grammar & Mechanics',
      weight: 20,
      levels: [
        { id: 'l4', score: 0, title: 'POOR', description: 'Frequent errors impede readability.', color: 'red' }, 
        { id: 'l5', score: 50, title: 'GOOD', description: 'Minor errors, generally clear.', color: 'amber' },
        { id: 'l6', score: 100, title: 'EXCELLENT', description: 'Flawless execution.', color: 'emerald' }
      ]
    }
  ]);

  const addToast = (message: string) => {
    const id = window.crypto.randomUUID();
    setToasts(prev => [...prev, { id, message }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 3000);
  };

  const handleSave = async () => {
    if (activeTab === 'assignment') {
      if (!authUser?.teacherId || !scopeClassId || !scopeSubject) {
        addToast('Error: class or subject data is missing.');
        return;
      }
      if (!title.trim()) {
        addToast('Please enter an assignment title first.');
        return;
      }
      setIsSavingReal(true);
      setSaveError('');
      const dueDateTime = dueDate ? `${dueDate}T${dueTime || '23:59'}` : null;
      const assignmentSettings = {
        maxScore,
        category,
        attemptLimit,
        allowLateSubmission,
        latePenalty: allowLateSubmission ? latePenalty : 'none',
        feedbackTiming,
        publishToTimeline,
        allowFileUpload,
        allowTextEntry,
        gradingMethod,
        passPercentage,
      };
      const assignmentPayload = { title: title.trim(), instructions: instructionsText, dueDate: dueDateTime, status: status === 'draft' ? 'Draft' as const : 'Active' as const, unitId: selectedUnitId || null, settings: assignmentSettings, rubric, attachments, assignedClasses, assignedStudents };
      const { id, error } = editId
        ? await updateAssignment(editId, assignmentPayload).then((r) => ({ id: r.ok ? editId : null, error: r.error }))
        : await createAssignment({ teacherId: authUser.teacherId, classId: scopeClassId, subject: scopeSubject }, assignmentPayload);
      setIsSavingReal(false);
      if (id) {
        addToast('Assignment Saved!');
        setTimeout(() => goBack(), 1000);
      } else {
        setSaveError(error || 'Unknown error');
        addToast(`Error while saving: ${error}`);
      }
      return;
    }
    // Quiz
    if (!authUser?.teacherId || !scopeClassId || !scopeSubject) {
      addToast('Error: class or subject data is missing.');
      return;
    }
    if (!title.trim()) {
      addToast('Please enter a quiz title first.');
      return;
    }
    setIsSavingReal(true);
    setSaveError('');
    const quizDueDateTime = dueDate ? `${dueDate}T${dueTime || '23:59'}` : null;
    const quizReleaseDateTime = hasReleaseCondition && releaseDate ? `${releaseDate}T${releaseTime || '00:00'}` : null;
    const quizSettings = {
      maxScore,
      category,
      timeLimitHours,
      timeLimitMinutes,
      attemptLimit,
      shuffleQuestions,
      oneAtATime,
      prohibitBacktracking,
      feedbackTiming,
      publishToTimeline,
      passPercentage,
      noDueDate,
      prohibitLateSubmissions,
      prohibitNewAttemptsAfterDueDate,
      randomizeAnswers,
      randomizePages,
    };
    const quizPayload = { title: title.trim(), dueDate: quizDueDateTime, releaseAt: quizReleaseDateTime, status: status === 'draft' ? 'Draft' as const : 'Active' as const, unitId: selectedUnitId || null, settings: quizSettings, questions, sections, assignedClasses, assignedStudents };
    const { id: quizId, error: quizError } = editId
      ? await updateQuiz(editId, quizPayload).then((r) => ({ id: r.ok ? editId : null, error: r.error }))
      : await createQuiz({ teacherId: authUser.teacherId, classId: scopeClassId, subject: scopeSubject }, quizPayload);
    setIsSavingReal(false);
    if (quizId) {
      addToast('Quiz Saved!');
      setTimeout(() => goBack(), 1000);
    } else {
      setSaveError(quizError || 'Unknown error');
      addToast(`Error while saving: ${quizError}`);
    }
  };

  const handleGenerateRubric = () => {
    setIsGeneratingRubric(true);
    addToast('Faheem is analyzing your assignment goal...');
    
    setTimeout(() => {
      setRubric([
        {
          id: `crit-${window.crypto.randomUUID()}`,
          title: 'Understanding of Core Concepts',
          weight: 35,
          levels: [
            { id: `l-${window.crypto.randomUUID()}`, score: gradingMethod === 'Percentage' ? 0 : 1, title: 'POOR', description: 'Demonstrates little to no understanding of the core concepts. Fails to apply them correctly.', color: 'red' },
            { id: `l-${window.crypto.randomUUID()}`, score: gradingMethod === 'Percentage' ? 50 : 3, title: 'GOOD', description: 'Shows a solid grasp of most concepts. Applies them correctly in standard scenarios.', color: 'amber' },
            { id: `l-${window.crypto.randomUUID()}`, score: gradingMethod === 'Percentage' ? 100 : 5, title: 'EXCELLENT', description: 'Exceptional mastery of all concepts. Can apply them creatively to novel situations.', color: 'emerald' }
          ]
        },
        {
          id: `crit-${window.crypto.randomUUID()}`,
          title: 'Analytical Depth',
          weight: 35,
          levels: [
            { id: `l-${window.crypto.randomUUID()}`, score: gradingMethod === 'Percentage' ? 0 : 1, title: 'POOR', description: 'Analysis is superficial or missing. Relies heavily on summary rather than insight.', color: 'red' },
            { id: `l-${window.crypto.randomUUID()}`, score: gradingMethod === 'Percentage' ? 50 : 3, title: 'GOOD', description: 'Provides good analysis with relevant evidence, though some points may lack depth.', color: 'amber' },
            { id: `l-${window.crypto.randomUUID()}`, score: gradingMethod === 'Percentage' ? 100 : 5, title: 'EXCELLENT', description: 'Profound and nuanced analysis. Connects ideas brilliantly with strong supporting evidence.', color: 'emerald' }
          ]
        },
        {
          id: `crit-${window.crypto.randomUUID()}`,
          title: 'Clarity & Organization',
          weight: 30,
          levels: [
            { id: `l-${window.crypto.randomUUID()}`, score: gradingMethod === 'Percentage' ? 0 : 1, title: 'POOR', description: 'Disorganized and difficult to follow. Frequent errors impede readability.', color: 'red' },
            { id: `l-${window.crypto.randomUUID()}`, score: gradingMethod === 'Percentage' ? 50 : 3, title: 'GOOD', description: 'Generally well-organized and clear. Minor errors do not detract from the overall message.', color: 'amber' },
            { id: `l-${window.crypto.randomUUID()}`, score: gradingMethod === 'Percentage' ? 100 : 5, title: 'EXCELLENT', description: 'Flawlessly organized with a logical flow. Writing is exceptionally clear and engaging.', color: 'emerald' }
          ]
        }
      ]);
      setIsGeneratingRubric(false);
      addToast('Faheem generated a new rubric!');
    }, 2000);
  };

  const [sections, setSections] = useState<QuizSection[]>([]);
  const [activeSectionId, setActiveSectionId] = useState<string | null>(null);
  const [draggedQId, setDraggedQId] = useState<string | null>(null);
  const [collapsedSectionIds, setCollapsedSectionIds] = useState<string[]>([]);
  const [collapsedQuestionIds, setCollapsedQuestionIds] = useState<string[]>([]);
  const toggleQuestionCollapse = (id: string) => {
    setCollapsedQuestionIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };
  const expandAllQuestions = () => setCollapsedQuestionIds([]);
  const collapseAllQuestions = () => setCollapsedQuestionIds(questions.map(q => q.id));

  const toggleSectionCollapse = (id: string) => {
    setCollapsedSectionIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };
  const expandAllSections = () => setCollapsedSectionIds([]);
  const collapseAllSections = () => setCollapsedSectionIds(sections.map(s => s.id));

  useEffect(() => {
    if (!editId) return;
    startTransition(() => setIsEditLoading(true));
    if (initialType === 'quiz') {
      getQuizById(editId).then((q) => {
        if (q) {
          setTitle(q.title);
          if (q.dueDate) { const [d, t] = q.dueDate.split('T'); setDueDate(d); setDueTime(t?.slice(0, 5) || '23:59'); }
          if (q.releaseAt) { const [d, t] = q.releaseAt.split('T'); setHasReleaseCondition(true); setReleaseDate(d); setReleaseTime(t?.slice(0, 5) || '00:00'); }
          setStatus(q.status === 'Draft' ? 'draft' : 'published');
          setQuestions(q.questions || []);
          setSections(q.sections || []);
          setAssignedClasses(q.assignedClasses || []);
          setAssignedStudents(q.assignedStudents || []);
          const s = q.settings || {};
          if (s.maxScore !== undefined) setMaxScore(s.maxScore);
          if (s.category !== undefined) setCategory(s.category);
          if (s.timeLimitHours !== undefined) setTimeLimitHours(s.timeLimitHours);
          if (s.timeLimitMinutes !== undefined) setTimeLimitMinutes(s.timeLimitMinutes);
          if (s.attemptLimit !== undefined) setAttemptLimit(s.attemptLimit);
          if (s.feedbackTiming !== undefined) setFeedbackTiming(s.feedbackTiming);
          if (s.publishToTimeline !== undefined) setPublishToTimeline(s.publishToTimeline);
          if (s.passPercentage !== undefined) setPassPercentage(s.passPercentage);
          if (s.noDueDate !== undefined) setNoDueDate(s.noDueDate);
          if (s.prohibitLateSubmissions !== undefined) setProhibitLateSubmissions(s.prohibitLateSubmissions);
          if (s.prohibitNewAttemptsAfterDueDate !== undefined) setProhibitNewAttemptsAfterDueDate(s.prohibitNewAttemptsAfterDueDate);
          if (s.randomizeAnswers !== undefined) setRandomizeAnswers(s.randomizeAnswers);
          if (s.randomizePages !== undefined) setRandomizePages(s.randomizePages);
        }
        setIsEditLoading(false);
      });
    } else {
      getAssignmentById(editId).then((a) => {
        if (a) {
          setTitle(a.title);
          setInstructionsText(a.instructions);
          if (a.dueDate) { const [d, t] = a.dueDate.split('T'); setDueDate(d); setDueTime(t?.slice(0, 5) || '23:59'); }
          setStatus(a.status === 'Draft' ? 'draft' : 'published');
          setRubric(a.rubric || []);
          setAttachments(a.attachments || []);
          setAssignedClasses(a.assignedClasses || []);
          setAssignedStudents(a.assignedStudents || []);
          const s = a.settings || {};
          if (s.maxScore !== undefined) setMaxScore(s.maxScore);
          if (s.category !== undefined) setCategory(s.category);
          if (s.attemptLimit !== undefined) setAttemptLimit(s.attemptLimit);
          if (s.allowLateSubmission !== undefined) setAllowLateSubmission(s.allowLateSubmission);
          if (s.latePenalty !== undefined) setLatePenalty(s.latePenalty);
          if (s.feedbackTiming !== undefined) setFeedbackTiming(s.feedbackTiming);
          if (s.publishToTimeline !== undefined) setPublishToTimeline(s.publishToTimeline);
          if (s.allowFileUpload !== undefined) setAllowFileUpload(s.allowFileUpload);
          if (s.allowTextEntry !== undefined) setAllowTextEntry(s.allowTextEntry);
          if (s.gradingMethod !== undefined) setGradingMethod(s.gradingMethod);
          if (s.passPercentage !== undefined) setPassPercentage(s.passPercentage);
        }
        setIsEditLoading(false);
      });
    }
  }, [editId]);

  const addSection = () => {
    const newSection: QuizSection = { id: `sec-${window.crypto.randomUUID()}`, title: `Section ${sections.length + 1}` };
    setSections(prev => [...prev, newSection]);
    setActiveSectionId(newSection.id);
    addToast('Section Added');
  };

  const deleteSection = (id: string) => {
    setSections(prev => prev.filter(s => s.id !== id));
    setQuestions(prev => prev.map(q => q.sectionId === id ? { ...q, sectionId: null } : q));
    if (activeSectionId === id) setActiveSectionId(null);
  };

  const updateSection = (id: string, updates: Partial<QuizSection>) => {
    setSections(prev => prev.map(s => s.id === id ? { ...s, ...updates } : s));
  };

  const addQuestion = (type: Question['type'], extra?: Partial<Question>) => {
    const newQuestionId = `q-${window.crypto.randomUUID()}`;
    const newQuestion: Question = {
      id: newQuestionId,
      type,
      text: '',
      points: 10,
      sectionId: activeSectionId,
      options: type === 'multiple_choice' ? [
        { id: `opt-${window.crypto.randomUUID()}`, text: 'Option 1', isCorrect: false },
        { id: `opt-${window.crypto.randomUUID()}`, text: 'Option 2', isCorrect: false }
      ] : type === 'true_false' ? [
        { id: `opt-${window.crypto.randomUUID()}`, text: 'True', isCorrect: false },
        { id: `opt-${window.crypto.randomUUID()}`, text: 'False', isCorrect: false }
      ] : undefined,
      numericAnswer: type === 'numeric_answer' ? null : undefined,
      numericTolerance: type === 'numeric_answer' ? 0 : undefined,
      pairs: type === 'matching' ? [
        { id: `p-${window.crypto.randomUUID()}`, left: '', right: '' },
        { id: `p-${window.crypto.randomUUID()}`, left: '', right: '' },
      ] : undefined,
      orderItems: type === 'ordering' ? ['', ''] : undefined,
      categories: type === 'classification' ? ['', ''] : undefined,
      classifyItems: type === 'classification' ? [{ text: '', category: '' }] : undefined,
      zones: type === 'drag_and_drop' ? ['', ''] : undefined,
      dragItems: type === 'drag_and_drop' ? [{ text: '', zone: '' }] : undefined,
      hotspots: type === 'hotspot' ? [] : undefined,
      subQuestions: type === 'passage' ? [] : undefined,
      ...extra,
    };
    setQuestions(prev => {
      if (!activeSectionId) {
        // لو مفيش قسم نشط، حطها في الآخر بعد كل حاجة مالهاش قسم
        const lastUngroupedIdx = prev.map(q => !q.sectionId).lastIndexOf(true);
        if (lastUngroupedIdx === -1) return [newQuestion, ...prev];
        return [...prev.slice(0, lastUngroupedIdx + 1), newQuestion, ...prev.slice(lastUngroupedIdx + 1)];
      }
      // حطها بعد آخر سؤال في نفس القسم النشط
      const lastInSectionIdx = prev.map(q => q.sectionId === activeSectionId).lastIndexOf(true);
      if (lastInSectionIdx === -1) {
        const sectionOrderIdx = sections.findIndex(s => s.id === activeSectionId);
        // لو القسم ده جديد ومفيهوش أسئلة، حطها في الآخر
        return [...prev, newQuestion];
      }
      return [...prev.slice(0, lastInSectionIdx + 1), newQuestion, ...prev.slice(lastInSectionIdx + 1)];
    });
    addToast('Question Added');
    setTimeout(() => {
      document.getElementById(`question-${newQuestionId}`)?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 100);
  };

  const deleteQuestion = (id: string) => {
    setQuestions(prev => prev.filter(q => q.id !== id));
    addToast('Question Deleted');
  };

  const duplicateQuestion = (id: string) => {
    setQuestions(prev => {
      const idx = prev.findIndex(q => q.id === id);
      if (idx === -1) return prev;
      const original = prev[idx];
      const copy: Question = {
        ...original,
        id: `q-${window.crypto.randomUUID()}`,
        options: original.options?.map(o => ({ ...o, id: `opt-${window.crypto.randomUUID()}` })),
      };
      return [...prev.slice(0, idx + 1), copy, ...prev.slice(idx + 1)];
    });
    addToast('Question Duplicated');
  };

  const updateQuestion = (id: string, updates: Partial<Question>) => {
    setQuestions(prev => prev.map(q => q.id === id ? { ...q, ...updates } : q));
  };

  const addRubricCriterion = () => {
    const newCrit: RubricCriterion = {
      id: `crit-${window.crypto.randomUUID()}`,
      title: 'New Criterion',
      weight: 10,
      levels: [
        { id: `l-${window.crypto.randomUUID()}`, score: 1, title: 'POOR', description: 'Needs improvement.', color: 'red' },
        { id: `l-${window.crypto.randomUUID()}`, score: 3, title: 'GOOD', description: 'Meets expectations.', color: 'amber' },
        { id: `l-${window.crypto.randomUUID()}`, score: 5, title: 'EXCELLENT', description: 'Exceeds expectations.', color: 'emerald' }
      ]
    };
    setRubric(prev => [...prev, newCrit]);
    addToast('Criterion Added');
  };

  const deleteRubricCriterion = (id: string) => {
    setRubric(prev => prev.filter(c => c.id !== id));
    addToast('Criterion Deleted');
  };

  const updateRubricCriterion = (id: string, updates: Partial<RubricCriterion>) => {
    setRubric(prev => prev.map(c => c.id === id ? { ...c, ...updates } : c));
  };

  if (isEditLoading) {
    return (
      <div className="min-h-screen bg-[#FAFAFA] flex items-center justify-center">
        <div className="flex flex-col items-center gap-3 text-slate-400">
          <Loader2 size={28} className="animate-spin" />
          <span className="text-sm font-bold">Loading assessment...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAFAFA] flex flex-col font-sans text-slate-900">
      {/* 1. Header */}
      <header className="h-16 bg-white border-b border-slate-200 px-6 flex items-center justify-between shrink-0 sticky top-0 z-[60]">
        <div className="flex items-center gap-4 flex-1">
          <button 
            onClick={goBack}
            className="p-2 hover:bg-slate-100 rounded-full text-slate-400 transition-colors"
            title="Back"
          >
            <ArrowLeft size={20} />
          </button>
          <button 
            onClick={() => router.push('/')}
            className="p-2 hover:bg-slate-100 rounded-full text-slate-400 transition-colors"
          >
            <Home size={20} />
          </button>
          <div className="flex flex-col">
            <div className="flex items-center gap-2 text-[10px] uppercase tracking-wider text-slate-400 font-bold">
              <Link href="/" className="hover:text-indigo-600 transition-colors">Course</Link>
              <span className="text-slate-300">/</span>
              <span>Unit 1</span>
              <span className="text-slate-300">/</span>
              <span className="text-slate-600">{activeTab === 'quiz' ? 'Quiz Builder' : 'Assignment Builder'}</span>
            </div>
            <h1 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <BrainCircuit size={16} className="text-indigo-600" />
              {title || 'Untitled Assessment'}
            </h1>
          </div>
        </div>

        <div className="flex items-center gap-3 flex-1 justify-end">
          {saveError && <span className="text-xs text-rose-600 font-bold">{saveError}</span>}
          <button 
            onClick={() => { setIsPreviewMode((p) => !p); setPreviewQuestionIndex(0); }}
            className={`font-bold text-sm px-4 py-2 rounded-xl transition-all flex items-center gap-2 ${isPreviewMode ? 'bg-indigo-50 text-indigo-600' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-100'}`}
          >
            <Eye size={16} /> {isPreviewMode ? 'Exit Preview' : 'Preview'}
          </button>
          <button 
            onClick={handleSave}
            disabled={isSavingReal}
            className="bg-indigo-600 text-white px-6 py-2.5 rounded-xl text-sm font-bold hover:bg-indigo-700 disabled:opacity-60 transition-all shadow-lg shadow-indigo-200 flex items-center gap-2"
          >
            <Save size={16} /> {isSavingReal ? 'Saving...' : 'Save'}
          </button>
        </div>
      </header>

      {/* Student Preview Overlay (نفس شكل الطالب بالظبط، مش بوب أب) */}
      {isPreviewMode && (
        <div className="flex-1 overflow-y-auto bg-[#FAFAFA]">
          <div className="p-8 max-w-2xl mx-auto flex flex-col gap-6 w-full">
            <div className="bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-bold px-4 py-2.5 rounded-xl flex items-center gap-2">
              <Eye size={14} /> Student Preview — this is exactly what a student will see
            </div>
            {activeTab === 'assignment' ? (
            <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
              <h2 className="text-2xl font-bold text-slate-800 mb-2">{title || 'Untitled'}</h2>
              {dueDate && (
                <div className="flex items-center gap-4 text-sm text-slate-500 mb-8 font-medium">
                  <span className="flex items-center gap-1"><AlertCircle size={16}/> Due: {new Date(`${dueDate}T${dueTime || '23:59'}`).toLocaleString()}</span>
                </div>
              )}
              <div className="mb-8">
                <h3 className="text-sm font-bold uppercase text-slate-400 tracking-wider mb-2">Instructions</h3>
                <p className="text-slate-600 leading-relaxed text-lg whitespace-pre-wrap">{instructionsText || 'No instructions yet.'}</p>
              </div>
              {attachments.length > 0 && (
                <div className="mb-8">
                  <h3 className="text-sm font-bold uppercase text-slate-400 tracking-wider mb-2">Attachments</h3>
                  <div className="space-y-2">
                    {attachments.map((a, i) => (
                      <div key={i} className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm font-bold text-indigo-600">
                        <FileText size={16} /> {a.name}
                      </div>
                    ))}
                  </div>
                </div>
              )}
              <div className="border-t border-slate-100 pt-6 space-y-6">
                {allowTextEntry && (
                  <div>
                    <h3 className="text-sm font-bold uppercase text-slate-400 tracking-wider mb-3">Written Response</h3>
                    <textarea disabled rows={5} className="w-full border border-slate-200 rounded-2xl p-5 text-slate-400 bg-slate-50 resize-none" placeholder="Type your answer or paste your links here..."></textarea>
                  </div>
                )}
                {allowFileUpload && (
                  <div>
                    <h3 className="text-sm font-bold uppercase text-slate-400 tracking-wider mb-3">File Upload</h3>
                    <div className="w-full border-2 border-dashed border-slate-200 rounded-2xl p-10 flex flex-col items-center justify-center text-slate-400 bg-slate-50">
                      <UploadCloud size={36} className="mb-4" />
                      <p className="font-bold">Drag & drop files here</p>
                    </div>
                  </div>
                )}
                <button disabled className="w-full py-4 bg-indigo-300 cursor-not-allowed text-white rounded-xl font-bold text-lg">
                  Submit Assignment
                </button>
              </div>
            </div>
            ) : (
            <>
              <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
                <h2 className="text-2xl font-bold text-slate-800 mb-2">{title || 'Untitled'}</h2>
                <div className="flex items-center gap-4 text-sm text-slate-500 font-medium flex-wrap">
                  {!noDueDate && dueDate && <span className="flex items-center gap-1"><AlertCircle size={16}/> Due: {new Date(`${dueDate}T${dueTime || '23:59'}`).toLocaleString()}</span>}
                  {(timeLimitHours !== '0' || timeLimitMinutes !== '0') && <span className="flex items-center gap-1"><Clock size={16}/> {timeLimitHours}h {timeLimitMinutes}m</span>}
                  <span className="flex items-center gap-1">{maxScore} pts</span>
                  {attemptLimit && <span className="flex items-center gap-1">Attempts: {attemptLimit === 'unlimited' ? 'Unlimited' : attemptLimit}</span>}
                  <span className="flex items-center gap-1">Pass: {passPercentage}%</span>
                  {oneAtATime && questions.length > 0 && <span className="flex items-center gap-1 font-bold text-indigo-600">Question {previewQuestionIndex + 1} of {questions.length}</span>}
                </div>
              </div>
              {questions.length === 0 && (
                <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm text-center text-slate-400">No questions yet.</div>
              )}
              {(() => {
                const questionsToShow = oneAtATime
                  ? (previewQuestionsShuffled[previewQuestionIndex] ? [previewQuestionsShuffled[previewQuestionIndex]] : [])
                  : previewQuestionsShuffled;
                return questionsToShow.map((q, i) => {
                  const idx = oneAtATime ? previewQuestionIndex : i;
                  const prevQ = oneAtATime ? null : questionsToShow[i - 1];
                  const showHeader = q.sectionId && (!prevQ || prevQ.sectionId !== q.sectionId);
                  const section = q.sectionId ? sections.find(s => s.id === q.sectionId) : null;
                  return (
                  <Fragment key={q.id}>
                    {showHeader && section && (
                      <div className="bg-slate-100 rounded-2xl p-4">
                        <h3 className="font-bold text-slate-700">{section.title}</h3>
                      </div>
                    )}
                    <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
                      <div className="flex justify-between items-start mb-4">
                        <p className="font-bold text-slate-800 flex-1">{idx + 1}. {q.text || 'Untitled question'}</p>
                        <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded-full shrink-0">{q.points} pts</span>
                      </div>
                      {q.imageUrl && <img src={q.imageUrl} alt="" className="max-h-48 rounded-xl border border-slate-200 mb-4" />}
                      {(q.type === 'multiple_choice' || q.type === 'true_false') && (
                        <div className="space-y-2">
                          {(randomizeAnswers ? [...(q.options || [])].reverse() : (q.options || [])).map((opt: any) => (
                            <label key={opt.id} className="flex items-center gap-3 p-3 rounded-xl border border-slate-200 cursor-not-allowed">
                              <input type="radio" disabled />
                              <span className="text-sm text-slate-600">{opt.text || 'Option'}</span>
                              {opt.imageUrl && <img src={opt.imageUrl} alt="" className="max-h-12 rounded-lg" />}
                            </label>
                          ))}
                        </div>
                      )}
                      {q.type === 'short_answer' && (
                        <div className="space-y-2">
                          {typeof q.correctAnswer === 'string' && (
                            <p className="text-xs font-bold text-violet-500 uppercase tracking-wider">Fill in the Blank {q.correctAnswer && <span className="text-slate-500 font-normal normal-case">— answer: {q.correctAnswer}</span>}</p>
                          )}
                          {typeof q.modelAnswer === 'string' && (
                            <p className="text-xs font-bold text-violet-500 uppercase tracking-wider">Essay {q.modelAnswer && <span className="text-slate-500 font-normal normal-case block mt-1">Model answer: {q.modelAnswer}</span>}</p>
                          )}
                          <textarea disabled rows={2} className="w-full border border-slate-200 rounded-xl p-3 text-slate-400 bg-slate-50 resize-none" placeholder="Student's answer..." />
                        </div>
                      )}
                      {q.type === 'file_upload' && (
                        <div className="border-2 border-dashed border-slate-200 rounded-xl p-6 flex items-center gap-3 text-slate-400 bg-slate-50">
                          <UploadCloud size={20} /> File upload
                        </div>
                      )}
                      {q.type === 'numeric_answer' && (
                        <p className="text-sm text-slate-500 bg-slate-50 rounded-xl p-3">Correct answer: <span className="font-bold text-slate-700">{q.numericAnswer}</span> {q.numericUnit || ''} (± {q.numericTolerance || 0})</p>
                      )}
                      {q.type === 'matching' && Array.isArray(q.pairs) && (
                        <div className="space-y-1.5">
                          {q.pairs.map((p: any) => (
                            <div key={p.id} className="flex items-center gap-2 text-sm text-slate-600 bg-slate-50 rounded-lg p-2">
                              <span className="font-medium">{p.left}</span> <ArrowRight size={12} className="text-slate-400" /> <span>{p.right}</span>
                            </div>
                          ))}
                        </div>
                      )}
                      {q.type === 'ordering' && Array.isArray(q.orderItems) && (
                        <ol className="list-decimal pr-5 space-y-1 text-sm text-slate-600">
                          {q.orderItems.map((it: string, i: number) => <li key={i}>{it}</li>)}
                        </ol>
                      )}
                      {q.type === 'classification' && Array.isArray(q.classifyItems) && (
                        <div className="space-y-1.5">
                          {q.classifyItems.map((it: any, i: number) => (
                            <div key={i} className="flex items-center gap-2 text-sm text-slate-600 bg-slate-50 rounded-lg p-2">
                              <span>{it.text}</span> <ArrowRight size={12} className="text-slate-400" /> <span className="font-bold">{it.category}</span>
                            </div>
                          ))}
                        </div>
                      )}
                      {q.type === 'drag_and_drop' && Array.isArray(q.dragItems) && (
                        <div className="space-y-1.5">
                          {q.dragItems.map((it: any, i: number) => (
                            <div key={i} className="flex items-center gap-2 text-sm text-slate-600 bg-slate-50 rounded-lg p-2">
                              <span>{it.text}</span> <ArrowRight size={12} className="text-slate-400" /> <span className="font-bold">{it.zone}</span>
                            </div>
                          ))}
                        </div>
                      )}
                      {q.type === 'hotspot' && q.imageUrl && (
                        <div className="text-xs text-slate-400 bg-slate-50 rounded-xl p-3">Interactive image question — {(q.hotspots || []).length} hotspot(s) marked</div>
                      )}
                      {q.type === 'passage' && (
                        <div className="space-y-3">
                          {q.passageText && <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs text-slate-600 whitespace-pre-wrap">{q.passageText}</div>}
                          {Array.isArray(q.subQuestions) && q.subQuestions.map((sq: any, i: number) => (
                            <p key={sq.id || i} className="text-xs text-slate-500">{i + 1}. {sq.title} <span className="text-slate-400">({sq.points} pts)</span></p>
                          ))}
                        </div>
                      )}
                    </div>
                  </Fragment>
                  );
                });
              })()}
              {oneAtATime && questions.length > 0 && (
                <div className="flex justify-between items-center gap-3">
                  <button
                    disabled={previewQuestionIndex === 0 || prohibitBacktracking}
                    onClick={() => setPreviewQuestionIndex((i) => Math.max(0, i - 1))}
                    className="px-6 py-3 bg-white border border-slate-200 text-slate-600 rounded-xl font-bold disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-50 transition-all"
                  >
                    Previous
                  </button>
                  {previewQuestionIndex < questions.length - 1 ? (
                    <button
                      onClick={() => setPreviewQuestionIndex((i) => Math.min(questions.length - 1, i + 1))}
                      className="px-6 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all"
                    >
                      Next
                    </button>
                  ) : (
                    <button disabled className="px-6 py-3 bg-indigo-300 cursor-not-allowed text-white rounded-xl font-bold">
                      Submit Quiz
                    </button>
                  )}
                </div>
              )}
              {!oneAtATime && questions.length > 0 && (
                <button disabled className="w-full py-4 bg-indigo-300 cursor-not-allowed text-white rounded-xl font-bold text-lg">
                  Submit Quiz
                </button>
              )}
            </>
            )}
          </div>
        </div>
      )}

      {!isPreviewMode && (
      <>
      {/* Main Content Grid */}
      <div className="flex-1 flex overflow-hidden">

        {/* 1.5 Question Type Panel (quiz only) — independent scroll, doesn't intersect with main or settings */}
        {activeTab === 'quiz' && (
          <aside className="w-56 shrink-0 h-full overflow-y-auto border-r border-slate-200 bg-white p-4 space-y-5">
            <div>
              <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3">Add Question</h4>
              <div className="space-y-2">
                {[
                  { type: 'multiple_choice', icon: ListChecks, label: 'Multiple Choice' },
                  { type: 'true_false', icon: CheckSquare, label: 'True/False' },
                  { type: 'short_answer', icon: Type, label: 'Short Answer' },
                  { type: 'short_answer', icon: AlignLeft, label: 'Fill in the Blank', extra: { correctAnswer: '' } },
                  { type: 'short_answer', icon: PenLine, label: 'Essay', extra: { modelAnswer: '' } },
                  { type: 'numeric_answer', icon: Calculator, label: 'Numeric Answer' },
                  { type: 'matching', icon: GitMerge, label: 'Matching' },
                  { type: 'ordering', icon: ListOrdered, label: 'Ordering' },
                  { type: 'classification', icon: Layers, label: 'Classification' },
                  { type: 'drag_and_drop', icon: Move, label: 'Drag & Drop' },
                  { type: 'hotspot', icon: MousePointerClick, label: 'Hotspot' },
                  { type: 'multiple_choice', icon: Mic, label: 'Audio Clip', extra: { audioUrl: '' } },
                  { type: 'passage', icon: Book, label: 'Passage' },
                  { type: 'file_upload', icon: UploadCloud, label: 'File Upload' }
                ].map((item: any, itemIdx) => (
                  <button 
                    key={`${item.type}-${itemIdx}`}
                    onClick={() => addQuestion(item.type as any, item.extra)}
                    className="w-full flex items-center gap-2.5 px-3 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-600 hover:border-indigo-300 hover:text-indigo-600 hover:bg-indigo-50 transition-all"
                  >
                    <item.icon size={16} />
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 space-y-2">
              <button
                onClick={() => addSection()}
                className="w-full flex items-center gap-2.5 px-3 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-600 hover:border-teal-300 hover:text-teal-600 hover:bg-teal-50 transition-all"
              >
                <Layout size={16} />
                Add Section
              </button>
            </div>

            <div className="pt-4 border-t border-slate-100 space-y-2">
              <button 
                onClick={() => setIsBankDrawerOpen(true)}
                className="w-full flex items-center gap-2 px-3 py-2.5 bg-slate-800 text-white rounded-xl text-xs font-bold hover:bg-slate-900 transition-all"
              >
                <Book size={16} />
                From Question Bank
              </button>
              <button 
                onClick={() => setIsAIDraftRoomOpen(true)}
                className="w-full flex items-center gap-2 px-3 py-2.5 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 text-white rounded-xl text-xs font-bold shadow-sm hover:shadow-md transition-all relative overflow-hidden"
              >
                <Sparkles size={16} className="animate-pulse" />
                Ask Faheem
              </button>
            </div>
          </aside>
        )}

        {/* 2. Left Canvas (Builder) — independent scroll */}
        <main className="flex-1 overflow-y-auto custom-scrollbar bg-[#FAFAFA] relative">
          <div className="p-12">
          <div className="max-w-4xl mx-auto">
            {activeTab === 'quiz' ? (
              <div className="space-y-8 pb-32">
                {questions.length > 0 && (
                  <div className="flex justify-end gap-2">
                    <button onClick={expandAllQuestions} className="px-3 py-1.5 text-xs font-bold text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors">
                      Expand All Questions
                    </button>
                    <button onClick={collapseAllQuestions} className="px-3 py-1.5 text-xs font-bold text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors">
                      Collapse All Questions
                    </button>
                  </div>
                )}
                {sections.length > 0 && (
                  <div className="flex justify-end gap-2">
                    <button onClick={expandAllSections} className="px-3 py-1.5 text-xs font-bold text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors">
                      Expand All
                    </button>
                    <button onClick={collapseAllSections} className="px-3 py-1.5 text-xs font-bold text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors">
                      Collapse All
                    </button>
                  </div>
                )}
                {/* Total Points Summary */}
                {questions.length > 0 && (() => {
                  const questionsSum = questions.reduce((sum, q) => sum + (q.points || 0), 0);
                  const hasMismatch = questionsSum !== maxScore;
                  return (
                    <div className="space-y-2">
                      <div className="bg-blue-50 border border-blue-100 rounded-2xl p-4 flex justify-between items-center">
                        <span className="text-sm font-bold text-blue-800">Sum of Question Points</span>
                        <span className="text-xl font-black text-blue-600">{questionsSum}</span>
                      </div>
                      {hasMismatch && (
                        <div className="flex items-start gap-2 bg-rose-50 border border-rose-200 rounded-xl p-3">
                          <AlertCircle size={16} className="text-rose-500 shrink-0 mt-0.5" />
                          <p className="text-xs font-bold text-rose-600 leading-snug">
                            {`Sum of question points (${questionsSum}) doesn't match the quiz's Total Points (${maxScore}).`}
                          </p>
                        </div>
                      )}
                    </div>
                  );
                })()}
                {/* Question List */}
                <AnimatePresence mode="popLayout">
                  {questions.map((q, idx) => {
                    const prevQ = questions[idx - 1];
                    const showSectionHeader = q.sectionId && (!prevQ || prevQ.sectionId !== q.sectionId);
                    const section = q.sectionId ? sections.find(s => s.id === q.sectionId) : null;
                    return (
                    <Fragment key={q.id}>
                      {showSectionHeader && section && (
                        <div
                          onClick={() => setActiveSectionId(section.id)}
                          className={`flex items-center justify-between p-5 rounded-2xl border-2 cursor-pointer transition-all ${activeSectionId === section.id ? 'border-teal-500 bg-teal-50' : 'border-slate-200 bg-white hover:border-teal-300'}`}
                        >
                          <div className="flex items-center gap-3 flex-1">
                            <button onClick={(e) => { e.stopPropagation(); toggleSectionCollapse(section.id); }} className="text-slate-400 hover:text-slate-600 shrink-0">
                              <ChevronDown size={18} className={`transition-transform ${collapsedSectionIds.includes(section.id) ? '-rotate-90' : ''}`} />
                            </button>
                            <input
                              type="text"
                              value={section.title}
                              onClick={(e) => e.stopPropagation()}
                              onChange={(e) => updateSection(section.id, { title: e.target.value })}
                              className="text-lg font-bold text-slate-800 bg-transparent border-none p-0 focus:ring-0 flex-1"
                            />
                          </div>
                          <button onClick={(e) => { e.stopPropagation(); deleteSection(section.id); }} className="text-slate-300 hover:text-rose-500 transition-colors shrink-0">
                            <Trash2 size={18} />
                          </button>
                        </div>
                      )}
                      {(!q.sectionId || !collapsedSectionIds.includes(q.sectionId)) && (
                    <motion.div 
                      id={`question-${q.id}`}
                      layout
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      draggable
                      onDragStart={() => setDraggedQId(q.id)}
                      onDragOver={(e) => e.preventDefault()}
                      onDrop={() => {
                        if (!draggedQId || draggedQId === q.id) return;
                        setQuestions(prev => {
                          const fromIdx = prev.findIndex(x => x.id === draggedQId);
                          const toIdx = prev.findIndex(x => x.id === q.id);
                          if (fromIdx === -1 || toIdx === -1) return prev;
                          const next = [...prev];
                          const [moved] = next.splice(fromIdx, 1);
                          next.splice(toIdx, 0, { ...moved, sectionId: q.sectionId });
                          return next;
                        });
                        setDraggedQId(null);
                      }}
                      className={`bg-white rounded-[24px] border-2 border-blue-500 p-8 relative group transition-all ${draggedQId === q.id ? 'opacity-40' : ''}`}
                    >
                      {/* Drag Handle */}
                      <div className="absolute -left-12 top-1/2 -translate-y-1/2 text-slate-300 cursor-grab opacity-0 group-hover:opacity-100 transition-opacity">
                        <GripVertical size={20} />
                      </div>

                      {/* Question Header */}
                      <div className="flex justify-between items-center mb-6">
                        <div className="flex items-center gap-2 text-blue-600 font-bold text-xs tracking-widest uppercase">
                          <span>QUESTION {idx + 1} •</span>
                          <select
                            value={q.type === 'short_answer' ? (typeof q.correctAnswer === 'string' ? 'fill_blank' : typeof q.modelAnswer === 'string' ? 'essay' : 'short_answer') : q.type}
                            onChange={(e) => {
                              const selected = e.target.value;
                              if (selected === 'fill_blank') {
                                updateQuestion(q.id, {
                                  type: 'short_answer', correctAnswer: q.correctAnswer ?? '', modelAnswer: undefined,
                                  options: undefined, numericAnswer: undefined, numericTolerance: undefined, pairs: undefined, orderItems: undefined, categories: undefined, classifyItems: undefined, zones: undefined, dragItems: undefined, hotspots: undefined, subQuestions: undefined,
                                });
                                return;
                              }
                              if (selected === 'essay') {
                                updateQuestion(q.id, {
                                  type: 'short_answer', modelAnswer: q.modelAnswer ?? '', correctAnswer: undefined,
                                  options: undefined, numericAnswer: undefined, numericTolerance: undefined, pairs: undefined, orderItems: undefined, categories: undefined, classifyItems: undefined, zones: undefined, dragItems: undefined, hotspots: undefined, subQuestions: undefined,
                                });
                                return;
                              }
                              const newType = selected as Question['type'];
                              updateQuestion(q.id, {
                                type: newType,
                                correctAnswer: undefined,
                                modelAnswer: undefined,
                                options: newType === 'multiple_choice' ? [
                                  { id: `opt-${window.crypto.randomUUID()}`, text: 'Option 1', isCorrect: false },
                                  { id: `opt-${window.crypto.randomUUID()}`, text: 'Option 2', isCorrect: false }
                                ] : newType === 'true_false' ? [
                                  { id: `opt-${window.crypto.randomUUID()}`, text: 'True', isCorrect: false },
                                  { id: `opt-${window.crypto.randomUUID()}`, text: 'False', isCorrect: false }
                                ] : undefined,
                                numericAnswer: newType === 'numeric_answer' ? null : undefined,
                                numericTolerance: newType === 'numeric_answer' ? 0 : undefined,
                                pairs: newType === 'matching' ? [
                                  { id: `p-${window.crypto.randomUUID()}`, left: '', right: '' },
                                  { id: `p-${window.crypto.randomUUID()}`, left: '', right: '' },
                                ] : undefined,
                                orderItems: newType === 'ordering' ? ['', ''] : undefined,
                                categories: newType === 'classification' ? ['', ''] : undefined,
                                classifyItems: newType === 'classification' ? [{ text: '', category: '' }] : undefined,
                                zones: newType === 'drag_and_drop' ? ['', ''] : undefined,
                                dragItems: newType === 'drag_and_drop' ? [{ text: '', zone: '' }] : undefined,
                                hotspots: newType === 'hotspot' ? [] : undefined,
                                subQuestions: newType === 'passage' ? [] : undefined,
                              });
                            }}
                            className="bg-blue-50 border-none rounded-lg text-xs font-bold uppercase text-blue-600 py-0.5 px-2 outline-none focus:ring-2 focus:ring-blue-200 cursor-pointer"
                          >
                            <option value="multiple_choice">Multiple Choice</option>
                            <option value="true_false">True/False</option>
                            <option value="short_answer">Short Answer</option>
                            <option value="fill_blank">Fill in the Blank</option>
                            <option value="essay">Essay</option>
                            <option value="numeric_answer">Numeric Answer</option>
                            <option value="matching">Matching</option>
                            <option value="ordering">Ordering</option>
                            <option value="classification">Classification</option>
                            <option value="drag_and_drop">Drag & Drop</option>
                            <option value="hotspot">Hotspot</option>
                            <option value="passage">Passage</option>
                            <option value="file_upload">File Upload</option>
                          </select>
                        </div>
                        <div className="flex items-center gap-4">
                          <div className="flex items-center gap-1.5 bg-blue-50 rounded-full px-3 py-1">
                            <input
                              type="number"
                              value={q.points}
                              onChange={(e) => updateQuestion(q.id, { points: e.target.value === '' ? 0 : (parseInt(e.target.value) || 0) })}
                              className="w-10 bg-transparent border-none p-0 text-center text-xs font-bold text-blue-600 focus:ring-0"
                            />
                            <span className="text-[10px] font-bold text-blue-600 uppercase">PTS</span>
                          </div>
                          <div className="flex items-center gap-4 text-slate-400">
                            <button onClick={() => toggleQuestionCollapse(q.id)} className="hover:text-slate-600 transition-colors" title={collapsedQuestionIds.includes(q.id) ? 'Expand' : 'Collapse'}>
                              <ChevronDown size={20} className={`transition-transform ${collapsedQuestionIds.includes(q.id) ? '-rotate-90' : ''}`} />
                            </button>
                            <button onClick={() => duplicateQuestion(q.id)} className="hover:text-slate-600 transition-colors" title="Duplicate">
                              <Copy size={20} />
                            </button>
                            <button 
                              onClick={() => deleteQuestion(q.id)}
                              className="hover:text-rose-500 transition-colors"
                            >
                              <Trash2 size={20} />
                            </button>
                          </div>
                        </div>
                      </div>

                      {collapsedQuestionIds.includes(q.id) && (
                        <p className="text-sm text-slate-500 truncate -mt-2 mb-2">{q.text || 'Untitled question'}</p>
                      )}

                      <AnimatePresence initial={false}>
                      {!collapsedQuestionIds.includes(q.id) && (
                      <motion.div
                        key="body"
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.25, ease: 'easeInOut' }}
                        style={{ overflow: 'hidden' }}
                      >
                      {/* Question Text */}
                      <div className="mb-8">
                        <textarea 
                          value={q.text}
                          onChange={(e) => updateQuestion(q.id, { text: e.target.value })}
                          rows={2}
                          className="w-full text-xl text-slate-800 font-bold bg-transparent border-none p-0 focus:ring-0 placeholder:text-slate-300 resize-none"
                          placeholder="What is the question?"
                        />
                        {q.imageUrl ? (
                          <div className="relative mt-3 inline-block">
                            <img src={q.imageUrl} alt="" className="max-h-48 rounded-xl border border-slate-200" />
                            <button onClick={() => updateQuestion(q.id, { imageUrl: undefined })} className="absolute -top-2 -right-2 bg-white border border-slate-200 rounded-full p-1 text-slate-500 hover:text-rose-600 shadow-sm">
                              <X size={14} />
                            </button>
                          </div>
                        ) : (
                          <label className="mt-3 inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-bold text-slate-500 hover:bg-slate-50 cursor-pointer">
                            <ImageIcon size={14} /> {isUploadingQImage === q.id ? 'Uploading...' : 'Insert Image'}
                            <input type="file" accept="image/*" className="hidden" onChange={async (e) => {
                              const file = e.target.files?.[0];
                              e.target.value = '';
                              if (!file) return;
                              setIsUploadingQImage(q.id);
                              const uploaded = await uploadAssignmentAttachment(file);
                              setIsUploadingQImage(null);
                              if (uploaded) updateQuestion(q.id, { imageUrl: getSubmissionFileUrl(uploaded.storagePath) });
                            }} />
                          </label>
                        )}
                      </div>

                      {/* Options (for MC / TF) */}
                      {(q.type === 'multiple_choice' || q.type === 'true_false') && (
                        <div className="space-y-4 mb-8">
                          {q.options?.map((opt, optIdx) => {
                            const letter = String.fromCharCode(65 + optIdx); // A, B, C, D...
                            return (
                              <div 
                                key={opt.id} 
                                className={`flex items-center gap-4 p-4 rounded-2xl border-2 transition-all group/opt ${
                                  opt.isCorrect 
                                    ? 'border-emerald-500 bg-emerald-50/30' 
                                    : 'border-slate-100 bg-white hover:border-slate-200'
                                }`}
                              >
                                <button 
                                  onClick={() => {
                                    const newOpts = q.options?.map(o => ({ ...o, isCorrect: o.id === opt.id }));
                                    updateQuestion(q.id, { options: newOpts });
                                  }}
                                  className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm transition-all shrink-0 ${
                                    opt.isCorrect 
                                      ? 'bg-emerald-500 text-white' 
                                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                                  }`}
                                >
                                  {letter}
                                </button>
                                <div className="flex-1 flex flex-col gap-2">
                                  <input 
                                    type="text" 
                                    value={opt.text}
                                    onChange={(e) => {
                                      const newOpts = q.options?.map(o => o.id === opt.id ? { ...o, text: e.target.value } : o);
                                      updateQuestion(q.id, { options: newOpts });
                                    }}
                                    className={`w-full bg-transparent border-none p-0 focus:ring-0 text-base font-medium outline-none ${
                                      opt.isCorrect ? 'text-emerald-900' : 'text-slate-800'
                                    }`}
                                    placeholder={`Option ${letter}`}
                                  />
                                  {opt.imageUrl && (
                                    <div className="relative inline-block w-fit">
                                      <img src={opt.imageUrl} alt="" className="max-h-20 rounded-lg border border-slate-200" />
                                      <button onClick={() => {
                                        const newOpts = q.options?.map(o => o.id === opt.id ? { ...o, imageUrl: undefined } : o);
                                        updateQuestion(q.id, { options: newOpts });
                                      }} className="absolute -top-1.5 -right-1.5 bg-white border border-slate-200 rounded-full p-0.5 text-slate-500 hover:text-rose-600 shadow-sm">
                                        <X size={10} />
                                      </button>
                                    </div>
                                  )}
                                </div>
                                {!opt.imageUrl && (
                                  <label className="text-slate-300 hover:text-slate-500 cursor-pointer shrink-0" title="Insert Image">
                                    {isUploadingOptImage === opt.id ? <span className="text-[10px]">...</span> : <ImageIcon size={16} />}
                                    <input type="file" accept="image/*" className="hidden" onChange={async (e) => {
                                      const file = e.target.files?.[0];
                                      e.target.value = '';
                                      if (!file) return;
                                      setIsUploadingOptImage(opt.id);
                                      const uploaded = await uploadAssignmentAttachment(file);
                                      setIsUploadingOptImage(null);
                                      if (uploaded) {
                                        const newOpts = q.options?.map(o => o.id === opt.id ? { ...o, imageUrl: getSubmissionFileUrl(uploaded.storagePath) } : o);
                                        updateQuestion(q.id, { options: newOpts });
                                      }
                                    }} />
                                  </label>
                                )}
                                {opt.isCorrect && (
                                  <CheckCircle2 size={24} className="text-emerald-500 shrink-0" />
                                )}
                                {!opt.isCorrect && q.type === 'multiple_choice' && (
                                  <button 
                                    onClick={() => {
                                      const newOpts = q.options?.filter(o => o.id !== opt.id);
                                      updateQuestion(q.id, { options: newOpts });
                                    }}
                                    className="opacity-0 group-hover/opt:opacity-100 text-slate-300 hover:text-rose-500 transition-opacity shrink-0"
                                  >
                                    <X size={20} />
                                  </button>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      )}

                      {q.type === 'short_answer' && typeof q.correctAnswer === 'string' && (
                        <div className="space-y-2 mb-8">
                          <div className="p-1 border border-slate-200 rounded-2xl bg-white focus-within:border-indigo-400 focus-within:ring-2 focus-within:ring-indigo-100 transition-all flex items-center pr-2">
                            <div className="w-8 h-8 rounded-xl bg-slate-100 flex items-center justify-center text-slate-400 shrink-0 ml-1">
                              <Type size={14} />
                            </div>
                            <input
                              type="text"
                              value={q.correctAnswer}
                              onChange={(e) => updateQuestion(q.id, { correctAnswer: e.target.value })}
                              placeholder="The missing word (correct answer)..."
                              className="w-full bg-transparent text-slate-800 text-sm font-bold px-4 py-3 outline-none placeholder:font-normal placeholder:text-slate-400"
                            />
                          </div>
                          <p className="text-xs font-semibold text-slate-400">Note: use the <span className="font-mono text-slate-600 bg-slate-100 px-1 py-0.5 rounded">___</span> symbol in the question text to mark the blank.</p>
                        </div>
                      )}

                      {q.type === 'short_answer' && typeof q.modelAnswer === 'string' && (
                        <div className="mb-8">
                          <textarea
                            value={q.modelAnswer}
                            onChange={(e) => updateQuestion(q.id, { modelAnswer: e.target.value })}
                            rows={4}
                            placeholder="Model answer or grading guide..."
                            className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-2xl p-4 font-bold text-sm outline-none focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 resize-none placeholder:font-normal placeholder:text-slate-400"
                          />
                        </div>
                      )}

                      {q.type === 'short_answer' && typeof q.correctAnswer !== 'string' && typeof q.modelAnswer !== 'string' && (
                        <div className="bg-slate-50 rounded-2xl border border-slate-100 p-6 text-slate-400 text-sm italic mb-8">
                          Students will provide a text-based response here.
                        </div>
                      )}

                      {q.type === 'file_upload' && (
                        <div className="bg-slate-50 rounded-2xl border border-slate-100 p-6 flex items-center gap-4 text-slate-400 text-sm mb-8">
                          <UploadCloud size={20} />
                          <span>Students will be prompted to upload a file (PDF, Image, or Doc).</span>
                        </div>
                      )}

                      {(q.type === 'numeric_answer' || q.type === 'matching' || q.type === 'ordering' || q.type === 'classification' || q.type === 'drag_and_drop' || q.type === 'hotspot' || q.type === 'passage') && (
                        <div className="mb-8">
                          {q.type === 'numeric_answer' && (
                            <div className="grid grid-cols-3 gap-3">
                              <div>
                                <label className="text-xs font-bold text-slate-500 mb-1.5 block">Correct Answer</label>
                                <input type="number" value={q.numericAnswer ?? ''} onChange={(e) => updateQuestion(q.id, { numericAnswer: e.target.value === '' ? null : Number(e.target.value) })} className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm font-bold text-slate-800 outline-none focus:ring-2 focus:ring-indigo-100" />
                              </div>
                              <div>
                                <label className="text-xs font-bold text-slate-500 mb-1.5 block">Tolerance (±)</label>
                                <input type="number" value={q.numericTolerance ?? 0} onChange={(e) => updateQuestion(q.id, { numericTolerance: Number(e.target.value) || 0 })} className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-indigo-100" />
                              </div>
                              <div>
                                <label className="text-xs font-bold text-slate-500 mb-1.5 block">Unit (optional)</label>
                                <input type="text" value={q.numericUnit || ''} onChange={(e) => updateQuestion(q.id, { numericUnit: e.target.value })} placeholder="e.g. cm, kg" className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-indigo-100" />
                              </div>
                            </div>
                          )}

                          {q.type === 'matching' && (
                            <div className="space-y-2">
                              {(q.pairs || []).map((p, pIdx) => (
                                <div key={p.id} className="flex items-center gap-2">
                                  <input value={p.left} onChange={(e) => { const pairs = [...(q.pairs || [])]; pairs[pIdx] = { ...pairs[pIdx], left: e.target.value }; updateQuestion(q.id, { pairs }); }} placeholder="Left item" className="flex-1 border border-slate-200 rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-indigo-100" />
                                  <ArrowRight size={16} className="text-slate-300 shrink-0" />
                                  <input value={p.right} onChange={(e) => { const pairs = [...(q.pairs || [])]; pairs[pIdx] = { ...pairs[pIdx], right: e.target.value }; updateQuestion(q.id, { pairs }); }} placeholder="Matches with" className="flex-1 border border-slate-200 rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-indigo-100" />
                                  {(q.pairs || []).length > 2 && (
                                    <button onClick={() => updateQuestion(q.id, { pairs: (q.pairs || []).filter((_, i) => i !== pIdx) })} className="text-slate-300 hover:text-red-500 transition-colors shrink-0"><Trash2 size={16} /></button>
                                  )}
                                </div>
                              ))}
                              <button onClick={() => updateQuestion(q.id, { pairs: [...(q.pairs || []), { id: `p-${window.crypto.randomUUID()}`, left: '', right: '' }] })} className="flex items-center gap-1.5 text-xs font-bold text-indigo-600 hover:text-indigo-700"><Plus size={14} /> Add pair</button>
                            </div>
                          )}

                          {q.type === 'ordering' && (
                            <div className="space-y-2">
                              {(q.orderItems || []).map((it, iIdx) => (
                                <div key={iIdx} className="flex items-center gap-2">
                                  <span className="w-6 h-6 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center text-xs font-bold shrink-0">{iIdx + 1}</span>
                                  <input value={it} onChange={(e) => { const items = [...(q.orderItems || [])]; items[iIdx] = e.target.value; updateQuestion(q.id, { orderItems: items }); }} placeholder={`Step ${iIdx + 1}`} className="flex-1 border border-slate-200 rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-indigo-100" />
                                  {(q.orderItems || []).length > 2 && (
                                    <button onClick={() => updateQuestion(q.id, { orderItems: (q.orderItems || []).filter((_, i) => i !== iIdx) })} className="text-slate-300 hover:text-red-500 transition-colors shrink-0"><Trash2 size={16} /></button>
                                  )}
                                </div>
                              ))}
                              <button onClick={() => updateQuestion(q.id, { orderItems: [...(q.orderItems || []), ''] })} className="flex items-center gap-1.5 text-xs font-bold text-indigo-600 hover:text-indigo-700"><Plus size={14} /> Add step</button>
                              <p className="text-xs text-slate-400">Enter items in the correct order — students will see them shuffled.</p>
                            </div>
                          )}

                          {q.type === 'classification' && (
                            <div className="space-y-4">
                              <div>
                                <label className="text-xs font-bold text-slate-500 mb-1.5 block">Categories</label>
                                <div className="flex flex-wrap gap-2 items-center">
                                  {(q.categories || []).map((cat, cIdx) => (
                                    <div key={cIdx} className="flex items-center gap-1 bg-slate-50 border border-slate-200 rounded-lg pl-2">
                                      <input value={cat} onChange={(e) => { const cats = [...(q.categories || [])]; const oldName = cats[cIdx]; cats[cIdx] = e.target.value; const items = (q.classifyItems || []).map(it => it.category === oldName ? { ...it, category: e.target.value } : it); updateQuestion(q.id, { categories: cats, classifyItems: items }); }} placeholder="Category" className="bg-transparent px-1 py-1.5 text-sm outline-none w-28" />
                                      {(q.categories || []).length > 2 && (
                                        <button onClick={() => updateQuestion(q.id, { categories: (q.categories || []).filter((_, i) => i !== cIdx) })} className="text-slate-300 hover:text-red-500 px-1"><X size={12} /></button>
                                      )}
                                    </div>
                                  ))}
                                  <button onClick={() => updateQuestion(q.id, { categories: [...(q.categories || []), ''] })} className="flex items-center gap-1 text-xs font-bold text-indigo-600 px-2"><Plus size={13} /> Add category</button>
                                </div>
                              </div>
                              <div>
                                <label className="text-xs font-bold text-slate-500 mb-1.5 block">Items to classify</label>
                                <div className="space-y-2">
                                  {(q.classifyItems || []).map((it, iIdx) => (
                                    <div key={iIdx} className="flex items-center gap-2">
                                      <input value={it.text} onChange={(e) => { const items = [...(q.classifyItems || [])]; items[iIdx] = { ...items[iIdx], text: e.target.value }; updateQuestion(q.id, { classifyItems: items }); }} placeholder="Item" className="flex-1 border border-slate-200 rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-indigo-100" />
                                      <select value={it.category} onChange={(e) => { const items = [...(q.classifyItems || [])]; items[iIdx] = { ...items[iIdx], category: e.target.value }; updateQuestion(q.id, { classifyItems: items }); }} className="border border-slate-200 rounded-xl px-3 py-2.5 text-sm outline-none">
                                        <option value="">Choose category</option>
                                        {(q.categories || []).map((cat, ci) => <option key={ci} value={cat}>{cat}</option>)}
                                      </select>
                                      {(q.classifyItems || []).length > 1 && (
                                        <button onClick={() => updateQuestion(q.id, { classifyItems: (q.classifyItems || []).filter((_, i) => i !== iIdx) })} className="text-slate-300 hover:text-red-500 shrink-0"><Trash2 size={16} /></button>
                                      )}
                                    </div>
                                  ))}
                                  <button onClick={() => updateQuestion(q.id, { classifyItems: [...(q.classifyItems || []), { text: '', category: '' }] })} className="flex items-center gap-1.5 text-xs font-bold text-indigo-600"><Plus size={14} /> Add item</button>
                                </div>
                              </div>
                            </div>
                          )}

                          {q.type === 'drag_and_drop' && (
                            <div className="space-y-4">
                              <div>
                                <label className="text-xs font-bold text-slate-500 mb-1.5 block">Drop Zones</label>
                                <div className="flex flex-wrap gap-2 items-center">
                                  {(q.zones || []).map((zone, zIdx) => (
                                    <div key={zIdx} className="flex items-center gap-1 bg-slate-50 border border-slate-200 rounded-lg pl-2">
                                      <input value={zone} onChange={(e) => { const zones = [...(q.zones || [])]; const oldName = zones[zIdx]; zones[zIdx] = e.target.value; const items = (q.dragItems || []).map(it => it.zone === oldName ? { ...it, zone: e.target.value } : it); updateQuestion(q.id, { zones, dragItems: items }); }} placeholder="Zone" className="bg-transparent px-1 py-1.5 text-sm outline-none w-28" />
                                      {(q.zones || []).length > 2 && (
                                        <button onClick={() => updateQuestion(q.id, { zones: (q.zones || []).filter((_, i) => i !== zIdx) })} className="text-slate-300 hover:text-red-500 px-1"><X size={12} /></button>
                                      )}
                                    </div>
                                  ))}
                                  <button onClick={() => updateQuestion(q.id, { zones: [...(q.zones || []), ''] })} className="flex items-center gap-1 text-xs font-bold text-indigo-600 px-2"><Plus size={13} /> Add zone</button>
                                </div>
                              </div>
                              <div>
                                <label className="text-xs font-bold text-slate-500 mb-1.5 block">Draggable Items</label>
                                <div className="space-y-2">
                                  {(q.dragItems || []).map((it, iIdx) => (
                                    <div key={iIdx} className="flex items-center gap-2">
                                      <input value={it.text} onChange={(e) => { const items = [...(q.dragItems || [])]; items[iIdx] = { ...items[iIdx], text: e.target.value }; updateQuestion(q.id, { dragItems: items }); }} placeholder="Item" className="flex-1 border border-slate-200 rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-indigo-100" />
                                      <select value={it.zone} onChange={(e) => { const items = [...(q.dragItems || [])]; items[iIdx] = { ...items[iIdx], zone: e.target.value }; updateQuestion(q.id, { dragItems: items }); }} className="border border-slate-200 rounded-xl px-3 py-2.5 text-sm outline-none">
                                        <option value="">Choose zone</option>
                                        {(q.zones || []).map((zone, zi) => <option key={zi} value={zone}>{zone}</option>)}
                                      </select>
                                      {(q.dragItems || []).length > 1 && (
                                        <button onClick={() => updateQuestion(q.id, { dragItems: (q.dragItems || []).filter((_, i) => i !== iIdx) })} className="text-slate-300 hover:text-red-500 shrink-0"><Trash2 size={16} /></button>
                                      )}
                                    </div>
                                  ))}
                                  <button onClick={() => updateQuestion(q.id, { dragItems: [...(q.dragItems || []), { text: '', zone: '' }] })} className="flex items-center gap-1.5 text-xs font-bold text-indigo-600"><Plus size={14} /> Add item</button>
                                </div>
                              </div>
                            </div>
                          )}

                          {q.type === 'hotspot' && (
                            <HotspotEditor
                              imageUrl={q.imageUrl || ''}
                              hotspots={q.hotspots || []}
                              isUploading={isUploadingQImage === q.id}
                              onUpload={async (file) => {
                                setIsUploadingQImage(q.id);
                                const result = await uploadQuestionImage(file);
                                setIsUploadingQImage(null);
                                if (result) updateQuestion(q.id, { imageUrl: result.url });
                              }}
                              onImageClick={(xPercent, yPercent) => {
                                const hotspots = [...(q.hotspots || []), { xPercent, yPercent, label: `${(q.hotspots || []).length + 1}`, isCorrect: (q.hotspots || []).length === 0 }];
                                updateQuestion(q.id, { hotspots });
                              }}
                              onMarkCorrect={(idx) => updateQuestion(q.id, { hotspots: (q.hotspots || []).map((h, i) => ({ ...h, isCorrect: i === idx })) })}
                              onRemoveHotspot={(idx) => updateQuestion(q.id, { hotspots: (q.hotspots || []).filter((_, i) => i !== idx) })}
                              onRemoveImage={() => updateQuestion(q.id, { imageUrl: undefined, hotspots: [] })}
                            />
                          )}

                          {q.type === 'passage' && (
                            <div className="space-y-4">
                              <div>
                                <label className="text-xs font-bold text-slate-500 mb-1.5 block">Passage Text</label>
                                <textarea
                                  value={q.passageText || ''}
                                  onChange={(e) => updateQuestion(q.id, { passageText: e.target.value })}
                                  rows={4}
                                  placeholder="Write the passage text here..."
                                  className="w-full border border-slate-200 rounded-xl p-3 text-sm text-slate-700 outline-none focus:ring-2 focus:ring-indigo-100 resize-y"
                                />
                              </div>
                              <div className="space-y-3">
                                {(q.subQuestions || []).map((sq, sqIdx) => (
                                  <SubQuestionEditor
                                    key={sq.id}
                                    subQuestion={sq}
                                    index={sqIdx}
                                    onUpdate={(patch) => {
                                      const subs = [...(q.subQuestions || [])];
                                      subs[sqIdx] = { ...subs[sqIdx], ...patch };
                                      updateQuestion(q.id, { subQuestions: subs });
                                    }}
                                    onDelete={() => updateQuestion(q.id, { subQuestions: (q.subQuestions || []).filter((_, i) => i !== sqIdx) })}
                                  />
                                ))}
                                <button
                                  onClick={() => updateQuestion(q.id, { subQuestions: [...(q.subQuestions || []), { id: `sq-${window.crypto.randomUUID()}`, title: '', type: 'اختيار من متعدد' as const, points: 1, options: [{ id: `o-${window.crypto.randomUUID()}`, text: '', isCorrect: true }, { id: `o-${window.crypto.randomUUID()}`, text: '', isCorrect: false }] }] })}
                                  disabled={(q.subQuestions || []).length >= 10}
                                  className="flex items-center gap-2 text-sm font-bold text-violet-600 hover:text-violet-700 disabled:opacity-40"
                                >
                                  <Plus size={16} /> Add Sub-Question
                                </button>
                                <p className="text-xs font-semibold text-slate-400">Total passage points: {(q.subQuestions || []).reduce((s, sq) => s + (sq.points || 0), 0)}</p>
                              </div>
                            </div>
                          )}
                        </div>
                      )}

                      {/* Footer */}
                      {q.type === 'multiple_choice' && (
                      <div className="flex items-center gap-4 pt-6 border-t border-slate-100">
                          <button 
                            onClick={() => {
                              const newOpts = [...(q.options || []), { id: `opt-${Date.now()}`, text: '', isCorrect: false }];
                              updateQuestion(q.id, { options: newOpts });
                            }}
                            className="flex items-center gap-2 text-sm font-semibold text-slate-400 hover:text-slate-600 transition-colors"
                          >
                            <Plus size={18} /> Add Option
                          </button>
                      </div>
                      )}
                      </motion.div>
                      )}
                      </AnimatePresence>
                    </motion.div>
                      )}
                    </Fragment>
                    );
                  })}
                </AnimatePresence>

                {sections.filter((sec) => !questions.some((q) => q.sectionId === sec.id)).map((sec) => (
                  <div
                    key={sec.id}
                    onClick={() => setActiveSectionId(sec.id)}
                    className={`flex items-center justify-between p-5 rounded-2xl border-2 cursor-pointer transition-all ${activeSectionId === sec.id ? 'border-teal-500 bg-teal-50' : 'border-slate-200 bg-white hover:border-teal-300'}`}
                  >
                    <div className="flex items-center gap-3 flex-1">
                      <input
                        type="text"
                        value={sec.title}
                        onClick={(e) => e.stopPropagation()}
                        onChange={(e) => updateSection(sec.id, { title: e.target.value })}
                        className="text-lg font-bold text-slate-800 bg-transparent border-none p-0 focus:ring-0 flex-1"
                      />
                      <span className="text-xs text-slate-400 shrink-0">No questions yet</span>
                    </div>
                    <button onClick={(e) => { e.stopPropagation(); deleteSection(sec.id); }} className="text-slate-300 hover:text-rose-500 transition-colors shrink-0">
                      <Trash2 size={18} />
                    </button>
                  </div>
                ))}

              </div>
            ) : (
              /* Assignment Builder Content */
              <div className="space-y-12 pb-32">
                
                {/* 1. Assignment Instructions Area */}
                <section className="space-y-6">
                  <div>
                    <h2 className="text-2xl font-bold text-slate-800">Assignment Instructions</h2>
                    <p className="text-slate-500 mt-1">Provide clear guidelines for your students.</p>
                  </div>
                  
                  <div className="bg-white rounded-[24px] border border-slate-200 shadow-sm p-8 space-y-6">
                    {/* Dropzone */}
                    <label className="border-2 border-dashed border-slate-200 rounded-2xl p-8 flex flex-col items-center justify-center text-center hover:bg-slate-50 hover:border-indigo-300 transition-all cursor-pointer group block">
                      <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                        <UploadCloud size={24} />
                      </div>
                      <h3 className="text-sm font-bold text-slate-700 mb-1">{isUploadingAttachment ? 'Uploading...' : 'Upload Instructions or Drag & Drop'}</h3>
                      <p className="text-xs text-slate-400">PDF, DOCX, or plain text up to 10MB</p>
                      <input
                        type="file"
                        className="hidden"
                        disabled={isUploadingAttachment}
                        onChange={async (e) => {
                          const file = e.target.files?.[0];
                          e.target.value = '';
                          if (!file) return;
                          setIsUploadingAttachment(true);
                          const uploaded = await uploadAssignmentAttachment(file);
                          setIsUploadingAttachment(false);
                          if (uploaded) setAttachments((prev) => [...prev, uploaded]);
                          else addToast('Error uploading attachment.');
                        }}
                      />
                    </label>

                    {attachments.length > 0 && (
                      <div className="space-y-2">
                        {attachments.map((a, i) => (
                          <div key={i} className="flex items-center justify-between bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5">
                            <span className="text-sm font-bold text-slate-700 truncate">{a.name}</span>
                            <button onClick={() => setAttachments((prev) => prev.filter((_, idx) => idx !== i))} className="text-slate-400 hover:text-rose-600">
                              <X size={16} />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}

                    <div className="flex items-center gap-4">
                      <div className="h-px bg-slate-100 flex-1"></div>
                      <span className="text-xs font-bold text-slate-300 uppercase tracking-widest">OR</span>
                      <div className="h-px bg-slate-100 flex-1"></div>
                    </div>

                    {/* Rich Text Area */}
                    <div>
                      <div className="border border-slate-200 rounded-2xl overflow-hidden focus-within:border-indigo-300 focus-within:ring-4 focus-within:ring-indigo-50 transition-all">
                        <div className="bg-slate-50 border-b border-slate-200 px-4 py-2 flex items-center gap-2">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Instructions</span>
                        </div>
                        <textarea 
                          value={instructionsText}
                          onChange={(e) => setInstructionsText(e.target.value)}
                          rows={6}
                          className="w-full p-4 text-sm text-slate-700 bg-white border-none focus:ring-0 resize-none placeholder:text-slate-300"
                          placeholder="Write detailed instructions here..."
                        />
                      </div>
                    </div>
                  </div>
                </section>

                {/* 2. The Colorful Rubric Builder */}
                <section className="space-y-6">
                  <div className="flex justify-between items-end">
                    <div>
                      <div className="flex items-center gap-4">
                        <h2 className="text-2xl font-bold text-slate-800">Grading Rubric</h2>
                        {activeTab !== 'assignment' && (
                        <div className="flex items-center bg-slate-100 p-1 rounded-xl">
                          {(['Points', 'Percentage', 'Scale'] as const).map(method => (
                            <button
                              key={method}
                              onClick={() => setGradingMethod(method)}
                              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${gradingMethod === method ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                            >
                              {method}
                            </button>
                          ))}
                        </div>
                        )}
                      </div>
                      <p className="text-slate-500 mt-1">Define how student work will be evaluated.</p>
                    </div>
                    <div className="flex gap-3">
                      <button 
                        onClick={handleGenerateRubric}
                        disabled={isGeneratingRubric}
                        className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
                          isGeneratingRubric 
                            ? 'bg-slate-100 text-slate-400 cursor-not-allowed' 
                            : 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:shadow-lg hover:shadow-indigo-200'
                        }`}
                      >
                        <Sparkles size={16} className={isGeneratingRubric ? "animate-pulse" : ""} /> 
                        {isGeneratingRubric ? 'Generating...' : 'AI Generate Rubric'}
                      </button>
                    </div>
                  </div>

                  <div className="space-y-6">
                    {rubric.map((crit) => (
                      <div key={crit.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm relative group overflow-hidden">
                        {/* Criterion Header */}
                        <div className="flex justify-between items-center p-4 border-b border-slate-100">
                          <div className="flex items-center gap-3 flex-1 max-w-md relative group/title">
                            <GripVertical size={16} className="text-slate-300 cursor-grab" />
                            <span className="text-slate-800 font-bold">Criterion:</span>
                            <input 
                              type="text" 
                              value={crit.title}
                              onChange={(e) => updateRubricCriterion(crit.id, { title: e.target.value })}
                              className="text-base font-bold text-slate-800 bg-transparent border-none p-0 focus:ring-0 placeholder:text-slate-300 w-full pr-8"
                              placeholder="Criterion Title"
                            />
                            <Pencil size={14} className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-300 opacity-0 group-hover/title:opacity-100 transition-opacity pointer-events-none" />
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="flex items-center bg-blue-50 rounded-full px-3 py-1 relative group/weight">
                              <span className="text-[10px] font-bold text-blue-600 uppercase mr-1">Weight:</span>
                              <input 
                                type="number" 
                                value={crit.weight}
                                onChange={(e) => updateRubricCriterion(crit.id, { weight: e.target.value === '' ? 0 : (parseInt(e.target.value) || 0) })}
                                className="w-8 bg-transparent border-none p-0 text-left text-[10px] font-bold text-blue-600 focus:ring-0"
                              />
                              <span className="text-[10px] font-bold text-blue-600 uppercase mr-4">{gradingMethod === 'Points' ? 'PTS' : '%'}</span>
                              <Pencil size={10} className="absolute right-2 top-1/2 -translate-y-1/2 text-blue-400 opacity-0 group-hover/weight:opacity-100 transition-opacity pointer-events-none" />
                            </div>
                            <button 
                              onClick={() => deleteRubricCriterion(crit.id)}
                              className="p-1.5 text-slate-300 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-all opacity-0 group-hover:opacity-100"
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        </div>

                        {/* Levels Grid */}
                        <div className="flex overflow-x-auto custom-scrollbar">
                          {crit.levels.map((lvl, idx) => {
                            const textColors = {
                              red: 'text-red-500',
                              amber: 'text-amber-500',
                              emerald: 'text-emerald-500',
                              blue: 'text-blue-500'
                            };
                            
                            return (
                              <div key={lvl.id} className={`flex-1 min-w-[200px] p-5 relative group/level ${idx !== crit.levels.length - 1 ? 'border-r border-slate-100' : ''}`}>
                                <div className="flex justify-between items-center mb-3">
                                  <div className="flex items-center flex-1">
                                    <input 
                                      type="text"
                                      value={lvl.title}
                                      onChange={(e) => {
                                        const newLevels = crit.levels.map(l => l.id === lvl.id ? { ...l, title: e.target.value } : l);
                                        updateRubricCriterion(crit.id, { levels: newLevels });
                                      }}
                                      className={`font-bold text-sm bg-transparent border-none p-0 focus:ring-0 uppercase tracking-wide w-[auto] max-w-[100px] ${textColors[lvl.color]}`}
                                    />
                                    <span className={`font-bold text-sm whitespace-nowrap ${textColors[lvl.color]}`}>
                                      (
                                    </span>
                                    <input 
                                      type="number" 
                                      value={lvl.score}
                                      onChange={(e) => {
                                        const newLevels = crit.levels.map(l => l.id === lvl.id ? { ...l, score: e.target.value === '' ? 0 : (parseInt(e.target.value) || 0) } : l);
                                        updateRubricCriterion(crit.id, { levels: newLevels });
                                      }}
                                      className={`w-8 bg-transparent border-none p-0 text-center text-sm font-bold focus:ring-0 ${textColors[lvl.color]}`}
                                    />
                                    <span className={`font-bold text-sm whitespace-nowrap ${textColors[lvl.color]}`}>
                                      {gradingMethod === 'Points' ? 'PTS' : gradingMethod === 'Percentage' ? '%' : 'LVL'})
                                    </span>
                                  </div>
                                  <Pencil size={12} className="text-slate-300 opacity-0 group-hover/level:opacity-100 transition-opacity" />
                                </div>
                                <div className="relative group/ldesc">
                                  <textarea 
                                    value={lvl.description}
                                    onChange={(e) => {
                                      const newLevels = crit.levels.map(l => l.id === lvl.id ? { ...l, description: e.target.value } : l);
                                      updateRubricCriterion(crit.id, { levels: newLevels });
                                    }}
                                    rows={3}
                                    className="w-full bg-transparent border-none p-0 text-sm italic text-slate-500 leading-relaxed focus:ring-0 resize-none pr-6"
                                    placeholder="Describe this level..."
                                  />
                                  <Pencil size={12} className="absolute right-1 top-2 opacity-0 group-hover/ldesc:opacity-50 transition-opacity pointer-events-none text-slate-400" />
                                </div>
                              </div>
                            );
                          })}
                          <button 
                            onClick={() => {
                              const newLevel = { id: `l-${window.crypto.randomUUID()}`, score: 0, title: 'NEW', description: 'Describe this level...', color: 'blue' as const };
                              updateRubricCriterion(crit.id, { levels: [...crit.levels, newLevel] });
                            }}
                            className="w-12 bg-slate-50 hover:bg-slate-100 flex items-center justify-center text-slate-400 hover:text-indigo-600 transition-all border-l border-slate-100 shrink-0"
                          >
                            <Plus size={16} />
                          </button>
                        </div>
                      </div>
                    ))}
                    
                    <button 
                      onClick={addRubricCriterion}
                      className="w-full py-4 border-2 border-dashed border-slate-200 rounded-[24px] text-slate-400 font-bold text-sm hover:border-indigo-300 hover:text-indigo-600 hover:bg-indigo-50 transition-all flex items-center justify-center gap-2"
                    >
                      <Plus size={18} /> Add New Criterion
                    </button>
                  </div>
                </section>
              </div>
            )}
          </div>
          </div>
        </main>

        {/* 3. Inspector Sidebar (Right) */}
        <AssessmentSidebar 
          language="en"
          activeTab={activeTab}
          title={title}
          setTitle={setTitle}
          status={status as any}
          setStatus={(s) => setStatus(s as any)}
          category={category}
          setCategory={setCategory}
          gradebookCategories={gradebookCategories}
          selectedUnitId={selectedUnitId}
          setSelectedUnitId={setSelectedUnitId}
          availableUnits={availableUnits}
          isUnitLocked={!!scopeUnitId}
          assignedClasses={assignedClasses}
          setAssignedClasses={setAssignedClasses}
          assignedStudents={assignedStudents}
          setAssignedStudents={setAssignedStudents}
          otherClasses={otherClasses}
          classRoster={classRoster}
          isAutoCalc={isAutoCalc}
          setIsAutoCalc={setIsAutoCalc}
          maxScore={maxScore}
          setMaxScore={setMaxScore}
          attemptLimit={attemptLimit}
          setAttemptLimit={setAttemptLimit}
          timeLimitHours={timeLimitHours}
          setTimeLimitHours={setTimeLimitHours}
          timeLimitMinutes={timeLimitMinutes}
          setTimeLimitMinutes={setTimeLimitMinutes}
          dueDate={dueDate}
          setDueDate={setDueDate}
          dueTime={dueTime}
          setDueTime={setDueTime}
          hasReleaseCondition={hasReleaseCondition}
          setHasReleaseCondition={setHasReleaseCondition}
          releaseDate={releaseDate}
          setReleaseDate={setReleaseDate}
          releaseTime={releaseTime}
          setReleaseTime={setReleaseTime}
          prohibitLateSubmissions={prohibitLateSubmissions}
          setProhibitLateSubmissions={setProhibitLateSubmissions}
          noDueDate={noDueDate}
          setNoDueDate={setNoDueDate}
          prohibitNewAttemptsAfterDueDate={prohibitNewAttemptsAfterDueDate}
          setProhibitNewAttemptsAfterDueDate={setProhibitNewAttemptsAfterDueDate}
          randomizeAnswers={randomizeAnswers}
          setRandomizeAnswers={setRandomizeAnswers}
          randomizePages={randomizePages}
          setRandomizePages={setRandomizePages}
          shuffleQuestions={shuffleQuestions}
          setShuffleQuestions={setShuffleQuestions}
          oneAtATime={oneAtATime}
          setOneAtATime={setOneAtATime}
          prohibitBacktracking={prohibitBacktracking}
          setProhibitBacktracking={setProhibitBacktracking}
          feedbackTiming={feedbackTiming}
          setFeedbackTiming={setFeedbackTiming}
          aiPlagiarism={aiPlagiarism}
          setAiPlagiarism={setAiPlagiarism}
          publishToTimeline={publishToTimeline}
          setPublishToTimeline={setPublishToTimeline}
          allowFileUpload={allowFileUpload}
          setAllowFileUpload={setAllowFileUpload}
          allowTextEntry={allowTextEntry}
          setAllowTextEntry={setAllowTextEntry}
          gradingMethod={gradingMethod}
          rubric={rubric as any}
          passPercentage={passPercentage}
          setPassPercentage={setPassPercentage}
          latePenalty={latePenalty}
          setLatePenalty={setLatePenalty}
          allowLateSubmission={allowLateSubmission}
          setAllowLateSubmission={setAllowLateSubmission}
          lockModule={lockModule}
          setLockModule={setLockModule}
        />
      </div>
      </>
      )}

      {/* Portals: AI Sidebar & Bank Drawer */}
      <FloatingPortal>
        <AnimatePresence>
          {isAIDraftRoomOpen && (
            <>
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsAIDraftRoomOpen(false)}
                className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[100]"
              />
              <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="fixed inset-4 md:inset-10 bg-white/90 backdrop-blur-xl shadow-2xl z-[110] flex flex-col rounded-[24px] border border-white/50 overflow-hidden max-w-4xl mx-auto"
              >
                {/* Header */}
                <div className="px-8 py-6 border-b border-slate-200/50 flex justify-between items-center bg-white/50">
                  <div className="flex items-center gap-4">
                    {hasGeneratedQuiz && (
                      <button onClick={() => setHasGeneratedQuiz(false)} className="p-2 hover:bg-slate-100 rounded-lg text-slate-500 transition-colors mr-2">
                        <ArrowLeft size={20} />
                      </button>
                    )}
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 text-white flex items-center justify-center shadow-lg shadow-indigo-200">
                      <Sparkles size={24} />
                    </div>
                    <div>
                      <h2 className="text-xl font-bold text-slate-800">
                        {hasGeneratedQuiz ? "Review AI Suggestions" : "Faheem AI Strategy Room"}
                      </h2>
                      <p className="text-sm text-slate-500">Unit 1: Matrix Operations</p>
                    </div>
                  </div>
                  <button onClick={() => setIsAIDraftRoomOpen(false)} className="p-3 hover:bg-slate-100 rounded-full text-slate-400 transition-colors">
                    <X size={24} />
                  </button>
                </div>

                {/* Main Content */}
                <div className="flex-1 bg-[#FAFAFA] flex flex-col overflow-hidden relative">
                  {!hasGeneratedQuiz ? (
                    <div className="flex-1 overflow-y-auto p-8">
                      {/* Strategy Commander Header */}
                      <div className="flex gap-4 mb-8 border-b border-slate-200/50 pb-4">
                        <button 
                          onClick={() => setStrategyTab('strategy')}
                          className={`pb-4 px-2 text-sm font-bold border-b-2 transition-colors -mb-[17px] ${
                            strategyTab === 'strategy' ? 'border-indigo-500 text-indigo-600' : 'border-transparent text-slate-400 hover:text-slate-600'
                          }`}
                        >
                          Strategy Commander
                        </button>
                        <button 
                          onClick={() => setStrategyTab('instant')}
                          className={`pb-4 px-2 text-sm font-bold border-b-2 transition-colors -mb-[17px] flex items-center gap-2 ${
                            strategyTab === 'instant' ? 'border-indigo-500 text-indigo-600' : 'border-transparent text-slate-400 hover:text-slate-600'
                          }`}
                        >
                          <Sparkles size={14} /> Instant Quizzes
                        </button>
                      </div>

                      {strategyTab === 'strategy' ? (
                        <div className="space-y-8">
                          {/* Magic Box */}
                          <div>
                            <label className="block text-sm font-bold text-slate-700 mb-2">Natural Language Prompt</label>
                            <div className="relative">
                              <textarea 
                                value={magicPrompt}
                                onChange={(e) => setMagicPrompt(e.target.value)}
                                placeholder="e.g., Create a hard challenge about Matrix Inverse for advanced students..."
                                className="w-full h-32 bg-white border border-slate-200 rounded-2xl p-4 text-slate-700 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none resize-none shadow-sm"
                              ></textarea>
                              <div className="absolute bottom-4 right-4 text-slate-300">
                                <Sparkles size={20} />
                              </div>
                            </div>
                          </div>

                          {/* Granular Controls */}
                          <div className="space-y-6">
                            <div className="grid grid-cols-2 gap-6">
                              <div className="space-y-2">
                                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider">Target Lessons</label>
                                <div className="flex flex-wrap gap-2">
                                  {['1.1', '1.2', '1.3'].map(lesson => (
                                    <button 
                                      key={lesson}
                                      onClick={() => setSelectedLessons(prev => prev.includes(lesson) ? prev.filter(l => l !== lesson) : [...prev, lesson])}
                                      className={`px-3 py-1.5 rounded-lg text-sm font-medium border transition-colors ${
                                        selectedLessons.includes(lesson) ? 'bg-indigo-50 border-indigo-200 text-indigo-700' : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                                      }`}
                                    >
                                      Lesson {lesson}
                                    </button>
                                  ))}
                                </div>
                              </div>
                              
                              <div className="space-y-2">
                                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider">Bloom&apos;s Taxonomy</label>
                                <select 
                                  value={selectedBloom}
                                  onChange={(e) => setSelectedBloom(e.target.value)}
                                  className="w-full bg-white border border-slate-200 rounded-xl p-2.5 text-sm text-slate-700 focus:ring-2 focus:ring-indigo-500 outline-none"
                                >
                                  <option value="Knowledge">Knowledge (Recall)</option>
                                  <option value="Application">Application (Use)</option>
                                  <option value="Analysis">Analysis (Break down)</option>
                                  <option value="Synthesis">Synthesis (Create)</option>
                                </select>
                              </div>
                            </div>

                            <div className="grid grid-cols-3 gap-6">
                              <div className="space-y-2">
                                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider">Learning Outcomes</label>
                                <select 
                                  className="w-full bg-white border border-slate-200 rounded-xl p-2.5 text-sm text-slate-700 focus:ring-2 focus:ring-indigo-500 outline-none"
                                >
                                  <option>Understand Dimensions</option>
                                  <option>Apply Multiplication Rules</option>
                                  <option>Invert Matrices</option>
                                  <option>Calculate Determinants</option>
                                </select>
                              </div>

                              <div className="space-y-2">
                                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider">Difficulty</label>
                                <div className="flex bg-slate-100 p-1 rounded-xl">
                                  {['Basic', 'Intermediate', 'Advanced'].map(diff => (
                                    <button 
                                      key={diff}
                                      onClick={() => setDifficulty(diff)}
                                      className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${
                                        difficulty === diff ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:text-slate-700'
                                      }`}
                                    >
                                      {diff}
                                    </button>
                                  ))}
                                </div>
                              </div>

                              <div className="space-y-2">
                                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider">Number of Questions</label>
                                <div className="flex items-center justify-between bg-[#FAFAFA] border border-slate-200 rounded-[12px] p-1 w-full max-w-[150px]">
                                  <button 
                                    onClick={() => setQuestionCount(Math.max(1, questionCount - 1))}
                                    className="w-8 h-8 flex items-center justify-center text-slate-500 hover:bg-white hover:shadow-sm rounded-lg transition-all"
                                  >
                                    <Minus size={16} />
                                  </button>
                                  <input 
                                    type="number" 
                                    value={questionCount}
                                    onChange={(e) => setQuestionCount(Math.max(1, parseInt(e.target.value) || 1))}
                                    className="w-12 text-center text-sm font-bold text-slate-700 bg-transparent border-none focus:ring-0 p-0 outline-none"
                                  />
                                  <button 
                                    onClick={() => setQuestionCount(questionCount + 1)}
                                    className="w-8 h-8 flex items-center justify-center text-slate-500 hover:bg-white hover:shadow-sm rounded-lg transition-all"
                                  >
                                    <Plus size={16} />
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div className="pt-4">
                            <button 
                              onClick={() => {
                                setIsGeneratingStrategy(true);
                                setTimeout(() => {
                                  setIsGeneratingStrategy(false);
                                  
                                  const baseQuestions = [
                                    {
                                      q: "What is the condition for multiplying two matrices A and B?",
                                      type: "Multiple Choice",
                                      lo: "Understand Matrix Dimensions",
                                      bloom: "Knowledge",
                                      options: [
                                        { text: "Columns of A = Rows of B", correct: true },
                                        { text: "Rows of A = Columns of B", correct: false },
                                        { text: "Both must be square matrices", correct: false }
                                      ]
                                    },
                                    {
                                      q: "If Matrix A is 3x2 and Matrix B is 2x4, what are the dimensions of the product AB?",
                                      type: "Multiple Choice",
                                      lo: "Apply Multiplication Rules",
                                      bloom: "Application",
                                      options: [
                                        { text: "3x4", correct: true },
                                        { text: "2x2", correct: false },
                                        { text: "4x3", correct: false }
                                      ]
                                    },
                                    {
                                      q: "Matrix multiplication is always commutative (AB = BA).",
                                      type: "True/False",
                                      lo: "Understand Matrix Dimensions",
                                      bloom: "Knowledge",
                                      options: [
                                        { text: "True", correct: false },
                                        { text: "False", correct: true }
                                      ]
                                    },
                                    {
                                      q: "Explain why the distributive property A(B + C) = AB + AC holds true for matrices.",
                                      type: "Short Answer",
                                      lo: "Apply Multiplication Rules",
                                      bloom: "Analysis",
                                      options: []
                                    },
                                    {
                                      q: "Given A = [[1, 2], [3, 4]] and B = [[2, 0], [1, 2]], calculate AB.",
                                      type: "Short Answer",
                                      lo: "Apply Multiplication Rules",
                                      bloom: "Application",
                                      options: []
                                    },
                                    {
                                      q: "Find the inverse of the matrix [[2, 1], [1, 1]].",
                                      type: "Short Answer",
                                      lo: "Invert Matrices",
                                      bloom: "Application",
                                      options: []
                                    },
                                    {
                                      q: "Calculate the determinant of a 3x3 identity matrix.",
                                      type: "Multiple Choice",
                                      lo: "Calculate Determinants",
                                      bloom: "Knowledge",
                                      options: [
                                        { text: "1", correct: true },
                                        { text: "0", correct: false },
                                        { text: "3", correct: false }
                                      ]
                                    }
                                  ];

                                  const newQuestions = Array.from({ length: questionCount }).map((_, i) => {
                                    const base = baseQuestions[i % baseQuestions.length];
                                    return {
                                      ...base,
                                      id: `gen-${i + 1}`,
                                      q: i >= baseQuestions.length ? `${base.q} (Variation ${Math.floor(i / baseQuestions.length) + 1})` : base.q
                                    };
                                  });

                                  setGeneratedQuestions(newQuestions);
                                  setHasGeneratedQuiz(true);
                                }, 2000);
                              }}
                              disabled={isGeneratingStrategy}
                              className="w-full py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-2xl font-bold shadow-lg shadow-indigo-200 hover:shadow-xl hover:shadow-indigo-300 transition-all flex items-center justify-center gap-2 relative overflow-hidden group"
                            >
                              {isGeneratingStrategy ? (
                                <>
                                  <Sparkles size={20} className="animate-pulse" />
                                  Analyzing Unit Content & Generating...
                                </>
                              ) : (
                                <>
                                  <div className="absolute inset-0 bg-white/20 group-hover:translate-x-full transition-transform duration-1000 -skew-x-12 -translate-x-full"></div>
                                  <Sparkles size={20} />
                                  ✨ Execute AI Strategy
                                </>
                              )}
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="grid grid-cols-3 gap-6">
                          {[
                            { title: "Weekly Review Quiz", desc: "Covers standard concepts from 1.1 to 1.3.", diff: "Intermediate", time: "15m", questions: 10 },
                            { title: "Deep Dive Assessment", desc: "Focuses heavily on Analysis and Synthesis.", diff: "Advanced", time: "30m", questions: 15 },
                            { title: "Quick Recap", desc: "Basic knowledge recall for all lessons.", diff: "Basic", time: "10m", questions: 5 }
                          ].map((quiz, i) => (
                            <div 
                              key={i} 
                              onClick={() => {
                                setIsGeneratingStrategy(true);
                                setTimeout(() => {
                                  setIsGeneratingStrategy(false);
                                  setGeneratedQuestions([
                                    {
                                      id: 'gen-1',
                                      q: "What is the condition for multiplying two matrices A and B?",
                                      type: "Multiple Choice",
                                      lo: "Understand Matrix Dimensions",
                                      bloom: "Knowledge",
                                      options: [
                                        { text: "Columns of A = Rows of B", correct: true },
                                        { text: "Rows of A = Columns of B", correct: false },
                                        { text: "Both must be square matrices", correct: false }
                                      ]
                                    },
                                    {
                                      id: 'gen-2',
                                      q: "If Matrix A is 3x2 and Matrix B is 2x4, what are the dimensions of the product AB?",
                                      type: "Multiple Choice",
                                      lo: "Apply Multiplication Rules",
                                      bloom: "Application",
                                      options: [
                                        { text: "3x4", correct: true },
                                        { text: "2x2", correct: false },
                                        { text: "4x3", correct: false }
                                      ]
                                    }
                                  ]);
                                  setHasGeneratedQuiz(true);
                                }, 1500);
                              }}
                              className="bg-white border border-slate-200 rounded-2xl p-6 hover:border-indigo-400 hover:shadow-lg hover:shadow-indigo-100 transition-all cursor-pointer group"
                            >
                              <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                                <Sparkles size={20} />
                              </div>
                              <h4 className="font-bold text-slate-800 mb-2">{quiz.title}</h4>
                              <p className="text-sm text-slate-500 mb-4">{quiz.desc}</p>
                              <div className="flex items-center gap-3 text-xs font-bold text-slate-400">
                                <span className="flex items-center gap-1"><Scale size={14} /> {quiz.diff}</span>
                                <span className="flex items-center gap-1"><Clock size={14} /> {quiz.time}</span>
                                <span className="flex items-center gap-1"><CheckCircle2 size={14} /> {quiz.questions} Qs</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                      
                      {/* Magic Glow Overlay during generation */}
                      <AnimatePresence>
                        {isGeneratingStrategy && (
                          <motion.div 
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            className="absolute inset-0 bg-white/80 backdrop-blur-sm z-10 flex flex-col items-center justify-center"
                          >
                            <div className="relative w-24 h-24 flex items-center justify-center">
                              <div className="absolute inset-0 bg-indigo-500 rounded-full animate-ping opacity-20"></div>
                              <div className="absolute inset-2 bg-purple-500 rounded-full animate-ping opacity-20" style={{ animationDelay: '0.2s' }}></div>
                              <div className="w-12 h-12 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-full flex items-center justify-center text-white shadow-xl shadow-indigo-200 z-10">
                                <Sparkles size={24} className="animate-pulse" />
                              </div>
                            </div>
                            <p className="mt-6 font-bold text-indigo-900 animate-pulse">Faheem is architecting your quiz...</p>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  ) : (
                    <div className="flex-1 overflow-y-auto p-8 relative">
                      {/* LO Coverage Summary */}
                      <div className="mb-8 bg-indigo-50/50 rounded-2xl p-6 border border-indigo-100">
                        <div className="flex justify-between items-center mb-4">
                          <h4 className="text-sm font-bold text-indigo-900 flex items-center gap-2">
                            <CheckCircle2 size={18} className="text-indigo-500" />
                            Learning Outcomes Coverage
                          </h4>
                          <span className="text-xs font-bold text-indigo-600 bg-indigo-100 px-2 py-1 rounded-lg">
                            {Math.round((new Set(generatedQuestions.map(q => q.lo)).size / 4) * 100)}% Covered
                          </span>
                        </div>
                        {/* Progress Bar */}
                        <div className="w-full h-2 bg-indigo-100 rounded-full mb-4 overflow-hidden">
                          <div 
                            className="h-full bg-emerald-500 rounded-full transition-all duration-1000" 
                            style={{ width: `${Math.round((new Set(generatedQuestions.map(q => q.lo)).size / 4) * 100)}%` }}
                          ></div>
                        </div>
                        <div className="flex flex-wrap gap-3">
                          {[
                            "Understand Matrix Dimensions",
                            "Apply Multiplication Rules",
                            "Invert Matrices",
                            "Calculate Determinants"
                          ].map(lo => {
                            const isCovered = new Set(generatedQuestions.map(q => q.lo)).has(lo);
                            return (
                              <div 
                                key={lo} 
                                className={`px-3 py-1.5 bg-white rounded-lg border ${isCovered ? 'border-indigo-200 text-indigo-700' : 'border-slate-200 text-slate-500 opacity-60'} text-xs font-bold flex items-center gap-2 shadow-sm`}
                              >
                                <div className={`w-2 h-2 rounded-full ${isCovered ? 'bg-emerald-500' : 'bg-slate-300'}`}></div>
                                {lo} {!isCovered && '(Missing)'}
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* Questions List */}
                      <div className="space-y-6">
                        {generatedQuestions.map((item, i) => (
                          <div key={item.id} className="bg-white border border-slate-200 rounded-2xl p-6 relative group hover:border-indigo-300 hover:shadow-md transition-all">
                            
                            <div className="flex justify-between items-start mb-4">
                              <div className="flex items-center gap-2">
                                <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2 py-1 rounded-md uppercase tracking-wider">Q{i+1} • {item.type}</span>
                                <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-md border border-emerald-100 flex items-center gap-1">
                                  🎯 {item.lo}
                                </span>
                                <span className="text-[10px] font-bold text-purple-600 bg-purple-50 px-2 py-1 rounded-md border border-purple-100">
                                  🧠 {item.bloom}
                                </span>
                              </div>
                              <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                <button 
                                  onClick={() => setGeneratedQuestions(generatedQuestions.filter(q => q.id !== item.id))}
                                  className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-colors"
                                >
                                  <Trash2 size={16} />
                                </button>
                              </div>
                            </div>
                            
                            <p className="w-full text-lg font-bold text-slate-800 mb-4">{item.q}</p>
                            
                            {item.options.length > 0 && (
                              <div className="space-y-2">
                                {item.options.map((opt: any, j: number) => (
                                  <div key={j} className={`flex items-center gap-3 p-3 rounded-xl border ${opt.correct ? 'border-emerald-200 bg-emerald-50/50' : 'border-slate-100 bg-slate-50'}`}>
                                    <div className={`w-5 h-5 rounded-full flex items-center justify-center border ${opt.correct ? 'border-emerald-500 bg-emerald-500 text-white' : 'border-slate-300 text-transparent'}`}>
                                      <CheckCircle2 size={12} />
                                    </div>
                                    <span className={`flex-1 text-sm ${opt.correct ? 'text-emerald-900 font-medium' : 'text-slate-600'}`}>
                                      {opt.text}
                                    </span>
                                  </div>
                                ))}
                              </div>
                            )}
                            {item.options.length === 0 && (
                              <div className="bg-slate-50 rounded-xl border border-slate-100 p-4 text-slate-400 text-sm italic">
                                Students will provide a text-based response here.
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Footer Action */}
                <div className="p-6 border-t border-slate-200/50 bg-white/50 flex justify-end gap-4 items-center">
                  <button onClick={() => setIsAIDraftRoomOpen(false)} className="px-6 py-3 text-slate-500 font-bold hover:bg-slate-100 rounded-xl transition-colors">
                    Discard Draft
                  </button>
                  <button 
                    onClick={() => {
                      setIsAIDraftRoomOpen(false);
                      setHasGeneratedQuiz(false); // Reset for next time
                      
                      // Map generated questions to the main builder format
                      const newQuestions: Question[] = generatedQuestions.map((gq, idx) => ({
                        id: `gen-imported-${Date.now()}-${idx}`,
                        type: gq.type === 'Multiple Choice' ? 'multiple_choice' : gq.type === 'True/False' ? 'true_false' : 'short_answer',
                        text: gq.q,
                        points: 10,
                        options: gq.options.map((opt: any, oIdx: number) => ({
                          id: `opt-${Date.now()}-${oIdx}`,
                          text: opt.text,
                          isCorrect: opt.correct
                        }))
                      }));
                      
                      setQuestions([...questions, ...newQuestions]);
                    }}
                    disabled={!hasGeneratedQuiz}
                    className={`flex items-center gap-2 px-8 py-3 rounded-xl font-bold transition-all ${
                      hasGeneratedQuiz 
                        ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-200 hover:shadow-xl hover:shadow-indigo-300 hover:-translate-y-0.5' 
                        : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                    }`}
                  >
                    <Sparkles size={18} />
                    ✨ Import to Quiz Builder
                  </button>
                </div>
              </motion.div>
            </>
          )}

          {isBankDrawerOpen && (
            <>
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsBankDrawerOpen(false)}
                className="fixed inset-0 bg-black/20 backdrop-blur-sm z-[100]"
              />
              <motion.div 
                initial={{ x: '100%' }}
                animate={{ x: 0 }}
                exit={{ x: '100%' }}
                className="fixed top-0 right-0 h-full w-[500px] bg-white shadow-2xl z-[110] flex flex-col border-l border-slate-100"
              >
                <div className="p-6 border-b border-slate-100 flex justify-between items-center">
                  <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                    <Book size={20} className="text-indigo-600" /> Question Bank
                  </h3>
                  <button onClick={() => setIsBankDrawerOpen(false)} className="p-2 hover:bg-slate-100 rounded-full text-slate-400 transition-colors">
                    <X size={20} />
                  </button>
                </div>
                <div className="p-4 border-b border-slate-50">
                  <div className="relative">
                    <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input type="text" value={bankSearch} onChange={(e) => setBankSearch(e.target.value)} placeholder="Search questions..." className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 pl-9 pr-4 text-sm outline-none focus:ring-2 focus:ring-indigo-100" />
                  </div>
                </div>
                <div className="flex-1 overflow-y-auto p-6 space-y-4">
                  {isLoadingBank ? (
                    <p className="text-center text-sm text-slate-400 py-10">Loading...</p>
                  ) : filteredBankQuestions.length === 0 ? (
                    <p className="text-center text-sm text-slate-400 py-10">No questions found for this subject/grade yet.</p>
                  ) : filteredBankQuestions.map(bq => (
                    <div key={bq.id} onClick={() => toggleBankSelection(bq.id)} className="flex items-start gap-4 p-4 border border-slate-100 rounded-2xl hover:bg-slate-50 transition-all cursor-pointer group">
                      <div className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-colors shrink-0 mt-0.5 ${selectedBankIds.includes(bq.id) ? 'bg-indigo-600 border-indigo-600' : 'border-slate-200 group-hover:border-indigo-500'}`}>
                        <Check size={12} className={selectedBankIds.includes(bq.id) ? 'text-white' : 'text-transparent group-hover:text-indigo-500'} />
                      </div>
                      <div>
                        <span className="text-[10px] font-bold text-slate-400 uppercase">{bq.unit}{bq.lesson ? ` • ${bq.lesson}` : ''}</span>
                        <p className="text-sm font-medium text-slate-700 mt-1">{bq.title}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="p-6 border-t border-slate-100">
                  <button onClick={handleAddSelectedBankQuestions} disabled={selectedBankIds.length === 0} className="w-full bg-slate-800 text-white py-3 rounded-xl font-bold hover:bg-slate-900 disabled:opacity-50 transition-all">
                    Add Selected Questions{selectedBankIds.length > 0 ? ` (${selectedBankIds.length})` : ''}
                  </button>
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </FloatingPortal>

      {/* Toasts */}
      <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-[200] flex flex-col gap-2">
        <AnimatePresence>
          {toasts.map(toast => (
            <motion.div 
              key={toast.id}
              initial={{ opacity: 0, y: 20, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-slate-800 text-white px-6 py-3 rounded-full text-sm font-bold shadow-2xl flex items-center gap-3"
            >
              <div className="w-5 h-5 rounded-full bg-indigo-500 flex items-center justify-center">
                <Check size={12} />
              </div>
              {toast.message}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}

export default function AssessmentBuilderPage() {
  return (
    <Suspense fallback={<div className="w-full h-screen flex items-center justify-center text-slate-400">Loading...</div>}>
      <AssessmentBuilderContent />
    </Suspense>
  );
}
