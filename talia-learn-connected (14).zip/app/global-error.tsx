'use client';

import * as Sentry from '@sentry/nextjs';
import { useEffect } from 'react';

// حد الأخطاء العام — بيتفعّل بس لو حصل كراش على مستوى التطبيق كله (نادر جدًا،
// الغالبية العظمى من الأخطاء بتتمسك جوه الصفحات نفسها بمنطقها الحالي).
// المهم هنا: أي كراش من النوع ده بقى بيتسجّل في Sentry تلقائي بدل ما يختفي
// بدون أي أثر.
export default function GlobalError({
  error,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    Sentry.captureException(error);
  }, [error]);

  return (
    <html lang="ar" dir="rtl">
      <body>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '100vh', fontFamily: 'sans-serif', textAlign: 'center', padding: 24 }}>
          <h1 style={{ fontSize: 24, fontWeight: 800, marginBottom: 8 }}>حصلت مشكلة غير متوقعة</h1>
          <p style={{ color: '#64748b', marginBottom: 24 }}>تم تسجيل المشكلة تلقائيًا، وهنشتغل على حلها.</p>
          <a href="/" style={{ padding: '10px 20px', background: '#4f46e5', color: 'white', borderRadius: 12, fontWeight: 700, textDecoration: 'none' }}>
            الرجوع للصفحة الرئيسية
          </a>
        </div>
      </body>
    </html>
  );
}
