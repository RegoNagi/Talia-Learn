import { NextRequest, NextResponse } from 'next/server';

// المسار ده بيبعت إيميل حقيقي عن طريق Resend. مفتاح الخدمة (RESEND_API_KEY)
// موجود على السيرفر بس، مش في كود المتصفح — عشان كده الإرسال لازم يمر من هنا.
export async function POST(request: NextRequest) {
  const { to, subject, bodyText } = await request.json();

  if (!to || !subject || !bodyText) {
    return NextResponse.json({ ok: false, error: 'Missing to/subject/bodyText' }, { status: 400 });
  }

  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    // مفيش مفتاح متظبط لسه — الطلب بيتجاهل نفسه بهدوء بدل ما يكسر أي حاجة.
    return NextResponse.json({ ok: false, error: 'Email not configured' }, { status: 200 });
  }

  const fromAddress = process.env.RESEND_FROM_EMAIL || 'Talia Learn <notifications@resend.dev>';

  try {
    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: fromAddress,
        to: [to],
        subject,
        text: bodyText,
      }),
    });

    if (!res.ok) {
      const errText = await res.text();
      console.error('Resend API error:', errText);
      return NextResponse.json({ ok: false, error: errText }, { status: 500 });
    }

    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error('Error sending email via Resend:', err);
    return NextResponse.json({ ok: false, error: 'Failed to send email' }, { status: 500 });
  }
}
