import { NextRequest, NextResponse } from 'next/server';
import { supabase } from '@/lib/supabaseClient';

const getBaseUrl = () => {
  if (process.env.APP_URL) return process.env.APP_URL;
  if (process.env.VERCEL_URL) return `https://${process.env.VERCEL_URL}`;
  return '';
};

const sendEmail = (to: string, subject: string, bodyText: string) =>
  fetch(`${getBaseUrl()}/api/notifications/send-email`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ to, subject, bodyText }),
  }).catch((err) => console.error('Error sending reminder email:', err));

// المسار ده Vercel Cron بيناديه تلقائي كل يوم — بيدوّر على الواجبات والاختبارات
// اللي موعدها خلال الـ٢٤ ساعة الجاية، وبيبعت تذكير إيميل لكل طلاب الفصل المعني.
// كل الإيميلات بتتبعت بالتوازي مع بعض (مش واحد ورا التاني) عشان الوظيفة تخلص
// في وقت قصير — مهم خصوصًا لأن الوظائف على خطة Hobby ليها حد ١٠ ثواني بس.
// ملاحظة: النسخة دي بتبعت لكل طلاب الفصل بدون استثناء اللي سلّم بالفعل — تحسين
// لاحق ممكن يستثنيهم لو حبينا.
export async function GET(request: NextRequest) {
  const authHeader = request.headers.get('authorization');
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const now = new Date();
  const in24h = new Date(now.getTime() + 24 * 60 * 60 * 1000).toISOString();

  const [{ data: dueAssignments }, { data: dueQuizzes }] = await Promise.all([
    supabase.from('assignments').select('id, title, due_date, class_id').eq('status', 'Active').not('due_date', 'is', null).gte('due_date', now.toISOString()).lte('due_date', in24h),
    supabase.from('quizzes').select('id, title, due_date, class_id').eq('status', 'Active').not('due_date', 'is', null).gte('due_date', now.toISOString()).lte('due_date', in24h),
  ]);

  const items = [
    ...(dueAssignments || []).map((a) => ({ ...a, kind: 'واجب' })),
    ...(dueQuizzes || []).map((q) => ({ ...q, kind: 'اختبار' })),
  ];

  if (items.length === 0) {
    return NextResponse.json({ ok: true, remindersSent: 0 });
  }

  const classIds = Array.from(new Set(items.map((i) => i.class_id).filter(Boolean)));
  const { data: enrollments } = await supabase.from('enrollments').select('class_id, student_id').in('class_id', classIds);

  const studentIds = Array.from(new Set((enrollments || []).map((e) => e.student_id)));
  const { data: studentRows } = await supabase.from('students').select('id, user_id').in('id', studentIds);
  const userIdByStudentId = new Map((studentRows || []).map((s) => [s.id, s.user_id]));

  const allUserIds = Array.from(new Set(Array.from(userIdByStudentId.values()).filter(Boolean)));
  const { data: userRows } = await supabase.from('users').select('id, email').in('id', allUserIds);
  const emailByUserId = new Map((userRows || []).map((u) => [u.id, u.email]));

  const emailPromises: Promise<unknown>[] = [];

  for (const item of items) {
    const classStudentIds = (enrollments || []).filter((e) => e.class_id === item.class_id).map((e) => e.student_id);
    const emails = classStudentIds
      .map((sid) => emailByUserId.get(userIdByStudentId.get(sid) || ''))
      .filter((e): e is string => !!e);

    for (const email of emails) {
      emailPromises.push(sendEmail(
        email,
        `تذكير: ${item.kind} "${item.title}" قرب موعده`,
        `تذكير من Talia Learn: عندك ${item.kind} بعنوان "${item.title}" موعده خلال الـ٢٤ ساعة الجاية.`
      ));
    }
  }

  await Promise.allSettled(emailPromises);

  return NextResponse.json({ ok: true, remindersSent: emailPromises.length });
}
