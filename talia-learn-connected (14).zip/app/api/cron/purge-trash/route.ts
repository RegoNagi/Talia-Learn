import { NextRequest, NextResponse } from 'next/server';
import { purgeAllOldTrash } from '@/services/todoData';

// المسار ده Vercel Cron بيناديه تلقائي كل يوم (زي ما محدد في vercel.json).
// محمي بمفتاح سري (CRON_SECRET) عشان محدش تاني يقدر يستدعيه غيرنا.
export async function GET(request: NextRequest) {
  const authHeader = request.headers.get('authorization');
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const result = await purgeAllOldTrash();

  if (!result.ok) {
    return NextResponse.json({ ok: false, error: result.error }, { status: 500 });
  }

  return NextResponse.json({ ok: true, deletedCount: result.deletedCount });
}
