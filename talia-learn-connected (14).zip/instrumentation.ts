import * as Sentry from '@sentry/nextjs';

// Next.js بيستدعي الدالة دي تلقائي وقت تشغيل السيرفر — بيحدد نشغّل إعداد
// Sentry بتاع السيرفر ولا بتاع Edge حسب البيئة الشغالة فيها.
export async function register() {
  if (process.env.NEXT_RUNTIME === 'nodejs') {
    await import('./sentry.server.config');
  }
  if (process.env.NEXT_RUNTIME === 'edge') {
    await import('./sentry.edge.config');
  }
}

export const onRequestError = Sentry.captureRequestError;
