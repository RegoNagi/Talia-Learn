// إعداد Sentry لبيئة Edge (middleware وأي كود شغال على Edge Runtime بتاع Vercel).
import * as Sentry from '@sentry/nextjs';

Sentry.init({
  dsn: process.env.NEXT_PUBLIC_SENTRY_DSN,
  tracesSampleRate: 0.1,
  environment: process.env.NEXT_PUBLIC_VERCEL_ENV || 'development',
});
